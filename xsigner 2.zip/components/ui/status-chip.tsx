type StatusChipProps = {
  children: React.ReactNode;
  tone?: "ready" | "muted" | "warning";
};

export function StatusChip({ children, tone = "muted" }: StatusChipProps) {
  const tones = {
    ready: "border-teal/25 bg-teal/10 text-teal",
    muted: "border-white/10 bg-white/[0.04] text-white/55",
    warning: "border-amber-300/25 bg-amber-300/10 text-amber-200"
  };
  return <span className={`inline-flex items-center gap-2 rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] ${tones[tone]}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{children}</span>;
}
