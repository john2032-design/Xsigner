import type { ButtonHTMLAttributes } from "react";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "violet" | "quiet";
};

export function Button({ className = "", tone = "violet", ...props }: ButtonProps) {
  const base = "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet focus-visible:ring-offset-2 focus-visible:ring-offset-graphite disabled:cursor-not-allowed disabled:opacity-45";
  const tones = tone === "violet" ? "bg-violet text-white shadow-glow hover:bg-violet/85" : "border border-white/10 bg-white/[0.04] text-white/80 hover:bg-white/[0.08]";
  return <button className={`${base} ${tones} ${className}`} {...props} />;
}
