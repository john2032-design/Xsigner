type FieldLabelProps = {
  title: string;
  hint?: string;
  optional?: boolean;
};

export function FieldLabel({ title, hint, optional = false }: FieldLabelProps) {
  return <div className="mb-2 flex items-baseline justify-between gap-3"><label className="text-xs font-semibold uppercase tracking-[0.16em] text-white/72">{title}</label><span className="mono text-[10px] text-white/30">{hint ?? (optional ? "optional" : "required")}</span></div>;
}
