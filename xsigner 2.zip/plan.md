# Xsigner implementation plan

## Scope

Transform the uploaded iOSign workspace into Xsigner, a permanently hosted Manus web app centered on IPA signing, certificate inspection, password utilities, free-certificate browsing, durable username/password accounts, and a private owner Discord-bot API reference.

## Design direction

- **Design movement:** adopt the connected GitHub repository’s XSIGN personal signing workspace template: a dark shadcn-admin-inspired operational dashboard with a fixed desktop rail, compact mobile drawer, and dense utility cards.
- **Core principles:** focused, transparent, responsive, and safe around signing secrets.
- **Color philosophy:** deep navy `#07111f` and raised blue-black cards `#0b1b2b` create a calm control-room canvas; Xsigner blue `#3197fd`, sky, and cyan accents mark actions, focus, active navigation, and progress states.
- **Layout paradigm:** persistent 252px desktop sidebar, sticky mobile header/drawer, wide workbench pages, grouped navigation labels, and information-dense asymmetric panels.
- **Signature elements:** the supplied Xsigner icon with XSIGN wordmark, mono eyebrow labels, sky-blue focus rings, thin translucent borders, grid texture, and cyan/blue progress indicators.
- **Interaction philosophy:** preserve every existing Xsigner tab and workflow while making navigation predictable, active states obvious, files readable, and owner/API surfaces visually private.
- **Animation:** restrained hover lift, soft active-phase pulse, loading orbit/progress treatment, and reduced-motion fallbacks.
- **Typography system:** Plus Jakarta Sans for readable utility text paired with JetBrains Mono for paths, API labels, route metadata, and operational details.
- **Brand essence:** a controlled IPA signing studio for builders who want a clear path from source package to installable build; precise, composed, hands-on.
- **Brand voice:** direct and reassuring. Example lines: “Sign the build. Keep the control.” and “Your signing set stays in your hands.”
- **Wordmark/mark:** use the supplied Xsigner icon beside the compact `XSIGN` workspace wordmark, retaining the icon asset rather than recreating it with generic text.
- **Signature brand color:** Xsigner blue `#3197fd`, supported by deep navy, sky, cyan, and slate neutrals.

## Implementation

- `app/studio-app.tsx` owns client-side navigation, responsive shell, Home, IPA Signer, Certificate Checker, P12 Password, Free certificates, traditional auth, Settings, Owner, and owner-only Discord API pages.
- IPA Signer groups certificate, provisioning profile, certificate password, bundle ID, custom icon, and tweaks into one signing-set card, while preserving saved-signing-set reuse.
- `app/api/sign` and `lib/signing-service.ts` preserve the local OpenSSL + rcodesign signing pipeline, including blank P12 passwords.
- `app/api/v1/discord/*` remains the private Bearer-authenticated bot surface; the owner-only page documents all endpoints, request fields, response examples, job lifecycle, and errors.
- `lib/certificates.ts` normalizes OpenSSL subject keys and exposes P12 Common Name, Organization, Issuer, validity, serial, and fingerprint; the checker accepts passwordless P12 files.
- Username/password authentication is the only visible sign-in/sign-up option. Durable account/session/settings storage uses the managed database, and settings supports profile pictures plus saved P12/mobileprovision sets.
- Home intentionally contains no Discord endpoint or bot feature card. Owner and Discord API navigation appears only for an authenticated owner session.
- `public/xsigner-icon.png`, metadata, `app.config.ts`, Tailwind tokens, global CSS, and route manifest carry the Xsigner blue/white branding.

## Product routes

`/`, `/sign-in`, `/settings`, `/ipa-signer`, `/certificate-checker`, `/p12-password`, `/free-certificates`, `/owner`, and `/discord-api` are declared page routes. APIs, assets, and system endpoints are excluded from the manifest.

## Deployment and validation

The project uses the managed Manus Webdev server feature and a Node container deployment. The health endpoint is `/api/health`; the production route table sends `/api/*` and page requests to the Next.js server. Validation includes type-checking, production build, route and auth-boundary assertions, route-manifest JSON validation, source privacy assertions, and stable production-server desktop/mobile screenshots.

## Follow-up design and API alignment

- Settings now follows the connected repository’s profile/certificate card treatment: avatar preview/upload, compact account identity, saved signing-set cards, expiration/status summary, privacy note, and progress feedback, while retaining Xsigner’s existing Settings tab and `/api/settings` storage behavior.
- Discord Sign and Custom Sign remain aliases over the same `signIpaInput` pipeline as the browser IPA Signer. Their multipart parser accepts the existing file names plus common `p12_password`, `p12Password`, and `bundle_id` aliases; bearer authentication and per-caller job polling remain enforced.

## Confirmed deployment updates

- The browser signer and Discord multipart API accept an optional app name (`appName` and `app_name`); the signer applies that value to `CFBundleDisplayName` and `CFBundleName`. OTA manifest metadata and the install result use the app name, so iOS identifies the public site domain and application name rather than exposing an identifier to the installer.
- `.deb` handling discovers valid dynamic libraries from `data.tar.*`, copies them into the app bundle without collisions, injects normalized `@executable_path` load commands, removes stale signatures, and leaves the final codesigning stage to sign the modified package. Every major step emits a named console event for the detailed IPA Signer progress view.
- Saved certificate controls include an explicit confirmation before deletion. Selecting the saved signing set hides manual certificate/profile/password upload controls until it is deselected.
- The owner dashboard is database-backed: it reports account, certificate, session, signing, signer-dependency, Discord API, and audit summaries, while owner-only requests require both an authenticated session and the trusted edge IP `168.91.23.165`.
- The Discord bearer credential is supplied solely as the server-side `IOSIGN_DISCORD_API_KEY` project secret. Neither UI output nor API documentation contains the credential.
