import StudioApp from "../studio-app";

export default async function Page({ params }: { params: Promise<{ slug?: string[] }> }) {
  const { slug = [] } = await params;
  return <StudioApp initialPath={`/${slug.join("/")}`} />;
}
