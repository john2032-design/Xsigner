"use client";

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Activity, ArrowRight, Bot, LogIn, LogOut, Settings, ShieldAlert, UserRound, ArrowUpRight, Check, CheckCircle2, ChevronRight, CircleAlert, CloudUpload, Download, FileArchive, FileKey2, FilePlus2, Fingerprint, KeyRound, LayoutDashboard, LoaderCircle, LockKeyhole, Menu, PackageCheck, QrCode, RefreshCw, ShieldCheck, Sparkles, UploadCloud, X, Zap } from "lucide-react";
import type { LucideIcon } from "lucide-react";

type PageKey = "home" | "signer" | "certificate-checker" | "p12-password" | "free-certificates" | "auth" | "settings" | "owner" | "discord-api";
type Phase = "Uploading" | "Modifying IPA" | "Injecting Tweaks" | "Signing" | "Generating Manifest";
type SignResult = { downloadUrl: string; otaUrl: string; manifestUrl: string; bundleId: string; version: string; appName: string; fileName: string };
type SigningEvent = { timestamp: string; stage: string; message: string; progress: number };
type SigningJob = { id: string; status: "queued" | "processing" | "completed" | "failed"; progress: number | null; stage: string; events: SigningEvent[]; result: SignResult | null; error: string | null };
type InspectionResult = { p12?: { status: string; subject?: Record<string, string>; issuer?: Record<string, string>; validFrom?: string; expiresAt?: string; fingerprint?: string }; mobileprovision?: { status: string; name: string; teamName: string; teamIdentifier: string; applicationIdentifier: string; uuid: string; expiration: string; getTaskAllow: boolean } };
type Certificate = { id: number; name: string; status: string; valid_from: string; valid_to: string; folder_name: string; nickname: string | null };

const phases: Phase[] = ["Uploading", "Modifying IPA", "Injecting Tweaks", "Signing", "Generating Manifest"];
const MAX_IPA_BYTES = 512 * 1024 * 1024;
const MAX_TWEAK_BYTES = 64 * 1024 * 1024;
const MAX_TWEAK_FILES = 24;
const phaseDescriptions: Record<Phase, string> = { Uploading: "Receive source files", "Modifying IPA": "Inspect and edit metadata", "Injecting Tweaks": "Stage optional tweaks", Signing: "OpenSSL + rcodesign + zsign", "Generating Manifest": "Publish a temporary OTA manifest" };
const violetButton = "inline-flex items-center justify-center gap-2 rounded-lg bg-blue-500 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-950/50 transition hover:bg-blue-400 disabled:cursor-not-allowed disabled:opacity-50";
const quietButton = "inline-flex items-center justify-center gap-2 rounded-lg border border-white/10 bg-white/[.04] px-4 py-3 text-sm font-medium text-slate-200 transition hover:border-blue-300/25 hover:bg-white/[.08] hover:text-white disabled:cursor-not-allowed disabled:opacity-50";
const inputClass = "w-full rounded-lg border border-white/10 bg-[#07111f] px-3 py-3 text-sm text-slate-100 outline-none transition placeholder:text-slate-500 focus:border-sky-300/60 focus:ring-2 focus:ring-sky-300/15";
const panelClass = "min-w-0 rounded-xl border border-white/[.075] bg-[#0b1b2b] p-4 shadow-[0_24px_70px_rgba(0,0,0,.22)] sm:p-5";
const navGroups: Array<{ title: string; items: Array<{ href: PageKey; label: string; icon: LucideIcon }> }> = [
  { title: "OVERVIEW", items: [{ href: "home", label: "Home", icon: LayoutDashboard }] },
  { title: "SIGNING", items: [{ href: "signer", label: "IPA Signer", icon: FileKey2 }] },
  { title: "CERTIFICATES", items: [{ href: "certificate-checker", label: "Certificate checker", icon: ShieldCheck }, { href: "p12-password", label: "P12 password", icon: KeyRound }, { href: "free-certificates", label: "Free certificates", icon: Zap }] },
  { title: "ACCOUNT", items: [{ href: "auth", label: "Sign in / Sign up", icon: LogIn }, { href: "settings", label: "Settings", icon: Settings }] }
];
const pathMap: Record<string, PageKey> = { "/": "home", "/sign-in": "auth", "/settings": "settings", "/owner": "owner", "/discord-api": "discord-api", "/ipa-signer": "signer", "/custom-sign": "signer", "/certificate-checker": "certificate-checker", "/p12-password": "p12-password", "/free-certificates": "free-certificates", "/enterprise-certificates": "free-certificates" };
const pagePaths: Record<PageKey, string> = { home: "/", auth: "/sign-in", settings: "/settings", owner: "/owner", "discord-api": "/discord-api", signer: "/ipa-signer", "certificate-checker": "/certificate-checker", "p12-password": "/p12-password", "free-certificates": "/free-certificates" };
const pageTitles: Record<PageKey, string> = { home: "Xsigner home", auth: "Account access", settings: "Settings", owner: "Owner console", "discord-api": "Discord API", signer: "IPA Signer", "certificate-checker": "Certificate checker", "p12-password": "P12 password", "free-certificates": "Free certificates" };
function formatBytes(bytes: number) { return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`; }
function pageFromPath(pathname: string): PageKey { return pathMap[pathname] ?? "home"; }
function Brand({ compact = false }: { compact?: boolean }) { return <div className="flex items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-xl border border-sky-300/25 bg-[#3197fd] shadow-lg shadow-blue-950/50"><img src="/xsigner-icon.png" alt="" className="h-full w-full object-cover" /></div>{!compact && <div><div className="text-[15px] font-extrabold tracking-[.14em] text-white">XSIGN</div><div className="mt-0.5 text-[10px] text-slate-500">Signing workspace</div></div>}</div>; }
function StatusChip({ children, tone = "ready" }: { children: ReactNode; tone?: "ready" | "warning" | "muted" | "danger" }) { const styles = { ready: "border-[#9ee1d1]/25 bg-[#9ee1d1]/[.08] text-[#9ee1d1]", warning: "border-[#3197fd]/30 bg-[#3197fd]/[.08] text-[#dbeafe]", muted: "border-white/10 bg-white/[.04] text-white/45", danger: "border-red-300/20 bg-red-300/[.06] text-red-200" }; return <span className={`inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[10px] font-semibold uppercase tracking-[.14em] ${styles[tone]}`}><span className={`h-1.5 w-1.5 rounded-full ${tone === "ready" ? "bg-[#9ee1d1]" : tone === "danger" ? "bg-red-300" : tone === "warning" ? "bg-[#3197fd]" : "bg-white/30"}`} />{children}</span>; }
function PageHeader({ eyebrow, title, children, action }: { eyebrow: string; title: string; children: ReactNode; action?: ReactNode }) { return <header className="mb-8 flex min-w-0 flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><div className="mono mb-3 flex items-center gap-2 text-[10px] uppercase tracking-[.2em] text-[#3197fd]"><Activity size={13} />{eyebrow}</div><h1 className="text-3xl font-semibold tracking-[-.045em] text-white sm:text-5xl">{title}<span className="text-[#3197fd]">.</span></h1><p className="mt-3 max-w-2xl text-sm leading-6 text-white/45">{children}</p></div>{action}</header>; }
function FileBay({ label, accept, file, onChange, icon: Icon, multiple = false, required = false }: { label: string; accept: string; file: File | File[] | null; onChange: (file: File | File[] | null) => void; icon: LucideIcon; multiple?: boolean; required?: boolean }) { const inputRef = useRef<HTMLInputElement>(null); const files = Array.isArray(file) ? file : file ? [file] : []; const selected = files.length > 0; return <div className="min-w-0 space-y-2"><div className="flex items-center justify-between gap-3"><label className="text-xs font-semibold text-white/60">{label}</label><span className="mono text-[9px] uppercase tracking-[.14em] text-white/25">{required ? "required" : "optional"}</span></div><button type="button" onClick={() => inputRef.current?.click()} className={`group flex min-h-[76px] w-full min-w-0 items-center gap-3 rounded-2xl border p-3 text-left transition hover:border-[#3197fd]/60 hover:bg-[#3197fd]/[.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3197fd] ${selected ? "border-[#3197fd]/60 bg-[#3197fd]/[.08]" : "border-white/10 bg-black/15"}`}><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl border bg-white/[.04] transition group-hover:border-[#3197fd]/40 group-hover:text-[#3197fd] ${selected ? "border-[#3197fd]/45 text-[#9ee1d1]" : "border-white/10 text-white/45"}`}><Icon size={18} /></span><span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium text-white/78">{files.length ? (files.length === 1 ? files[0].name : `${files.length} tweak files selected`) : `Choose ${label.toLowerCase()}`}</span><span className={`mono mt-1 block truncate text-[10px] uppercase tracking-[.12em] ${selected ? "text-[#9ee1d1]/75" : "text-white/25"}`}>{files.length ? `${files.map((item) => formatBytes(item.size)).join(" · ")} · ready` : accept.replaceAll(".", "").replaceAll(",", " / ")}</span></span>{selected && <Check size={15} className="shrink-0 text-[#9ee1d1]" />}<ChevronRight size={16} className="text-white/20 transition group-hover:translate-x-0.5 group-hover:text-[#3197fd]" /></button><input ref={inputRef} className="file-input" type="file" accept={accept} multiple={multiple} onChange={(event) => { const selectedFiles = Array.from(event.target.files ?? []); onChange(multiple ? selectedFiles : selectedFiles[0] ?? null); }} /></div>; }

function HomePage({ navigate }: { navigate: (page: PageKey) => void }) { return <div className="space-y-7"><section className="relative overflow-hidden rounded-[2rem] border border-[#3197fd]/20 bg-[radial-gradient(circle_at_82%_15%,rgba(49,151,253,.22),transparent_28%),linear-gradient(135deg,#102b4d,#0d2240_52%,#0a192a)] p-6 sm:p-10 lg:p-14"><div className="absolute right-8 top-8 h-32 w-32 rounded-full border border-[#3197fd]/20" /><div className="absolute -right-8 top-16 h-32 w-32 rounded-full border border-[#3197fd]/10" /><div className="relative max-w-3xl"><StatusChip tone="warning">Xsigner / local-first</StatusChip><h1 className="mt-6 max-w-3xl text-4xl font-semibold tracking-[-.06em] text-white sm:text-6xl">Sign the build.<br /><span className="bg-gradient-to-r from-sky-200 via-cyan-200 to-blue-300 bg-clip-text text-transparent">Keep the control.</span></h1><p className="mt-6 max-w-2xl text-base leading-7 text-white/60">A focused iOS signing workspace for people who want a clear path from IPA to installable package. Your signing set stays in your hands while Xsigner handles the repetitive packaging work.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><button className={violetButton} type="button" onClick={() => navigate("signer")}><FileKey2 size={17} /> Open IPA Signer <ArrowRight size={16} /></button><button className={quietButton} type="button" onClick={() => navigate("free-certificates")}><Zap size={16} /> Browse free certificates</button></div></div></section><div className="grid gap-5 md:grid-cols-2"><FeatureCard icon={FileKey2} eyebrow="01 / IPA" title="A deliberate signing flow" detail="Upload the app, certificate, profile, and optional tweaks. Follow each phase as the local signing pipeline works." action="Open signer" onClick={() => navigate("signer")} /><FeatureCard icon={ShieldCheck} eyebrow="02 / CHECK" title="Inspect before you sign" detail="Read certificate identity, validity, profile metadata, and entitlements without sending secrets to a marketplace." action="Check a set" onClick={() => navigate("certificate-checker")} /></div></div>; }
function FeatureCard({ icon: Icon, eyebrow, title, detail, action, onClick }: { icon: LucideIcon; eyebrow: string; title: string; detail: string; action: string; onClick: () => void }) { return <section className={`${panelClass} group transition hover:-translate-y-1 hover:border-[#3197fd]/35`}><div className="flex items-center justify-between"><div className="grid h-10 w-10 place-items-center rounded-xl bg-[#3197fd]/[.09] text-[#3197fd]"><Icon size={19} /></div><Sparkles size={16} className="text-white/20 transition group-hover:text-[#3197fd]" /></div><div className="mono mt-6 text-[10px] uppercase tracking-[.2em] text-white/30">{eyebrow}</div><h2 className="mt-2 text-lg font-semibold text-white">{title}</h2><p className="mt-3 min-h-[72px] text-sm leading-6 text-white/40">{detail}</p><button className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-[#3197fd]" type="button" onClick={onClick}>{action}<ArrowUpRight size={15} /></button></section>; }

function SignerPage({ session }: { session: any }) {
  const [ipa, setIpa] = useState<File | null>(null);
  const [certificate, setCertificate] = useState<File | null>(null);
  const [profile, setProfile] = useState<File | null>(null);
  const [icon, setIcon] = useState<File | null>(null);
  const [tweaks, setTweaks] = useState<File[]>([]);
  const [password, setPassword] = useState("");
  const [bundleId, setBundleId] = useState("");
  const [appName, setAppName] = useState("");
  const [useSaved, setUseSaved] = useState(false);
  const [job, setJob] = useState<SigningJob | null>(null);
  const [error, setError] = useState("");
  const [result, setResult] = useState<SignResult | null>(null);
  const [dragging, setDragging] = useState(false);
  const [starting, setStarting] = useState(false);
  const [statusModalOpen, setStatusModalOpen] = useState(false);

  const processing = Boolean(job && (job.status === "queued" || job.status === "processing"));
  const busy = starting || processing;
  const handleIpa = (file: File | null) => {
    if (file && file.name.toLowerCase().endsWith(".ipa") && file.size <= MAX_IPA_BYTES) { setIpa(file); setError(""); }
    else if (file && file.name.toLowerCase().endsWith(".ipa")) setError("This IPA is larger than the 512 MB limit. Choose a smaller package.");
    else if (file) setError("The application package must use the .ipa extension.");
  };
  const handleTweaks = (value: File | File[] | null) => {
    const selected = Array.isArray(value) ? value : value ? [value] : [];
    if (selected.length > MAX_TWEAK_FILES) { setError(`Choose no more than ${MAX_TWEAK_FILES} tweak files.`); return; }
    const invalid = selected.find((file) => !file.name.toLowerCase().endsWith(".deb") && !file.name.toLowerCase().endsWith(".dylib"));
    if (invalid) { setError(`${invalid.name} is not a supported .deb or .dylib tweak.`); return; }
    const oversized = selected.find((file) => file.size > MAX_TWEAK_BYTES);
    if (oversized) { setError(`${oversized.name} is larger than the 64 MB tweak limit.`); return; }
    setTweaks(selected); setError("");
  };

  useEffect(() => {
    if (!job || !["queued", "processing"].includes(job.status)) return;
    let active = true;
    let timeout: ReturnType<typeof setTimeout> | undefined;
    const poll = async () => {
      try {
        const response = await fetch(`/api/sign/jobs/${encodeURIComponent(job.id)}`, { cache: "no-store" });
        const next = await response.json();
        if (!response.ok) throw new Error(next.error || "The signing job could not be read.");
        if (!active) return;
        setJob(next);
        if (next.status === "completed" && next.result) { setResult(next.result as SignResult); setStatusModalOpen(true); }
        if (next.status === "failed") { setError(next.error || "Signing could not be completed."); setStatusModalOpen(true); }
        if (["queued", "processing"].includes(next.status)) timeout = setTimeout(poll, 950);
      } catch (cause) {
        if (active) setError(cause instanceof Error ? cause.message : "The signing job could not be read.");
      }
    };
    void poll();
    return () => { active = false; if (timeout) clearTimeout(timeout); };
  }, [job?.id, job?.status]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(""); setResult(null); setJob(null); setStarting(true); setStatusModalOpen(true);
    if (!ipa || (useSaved && !session) || (!useSaved && (!certificate || !profile))) {
      setError(useSaved ? "Add the IPA and save a signing set in Settings first." : "Add the IPA, certificate, and provisioning profile before signing.");
      setStarting(false);
      return;
    }
    if (ipa.size > MAX_IPA_BYTES) { setError("The IPA must be 512 MB or smaller."); setStarting(false); setStatusModalOpen(false); return; }
    if (tweaks.length > MAX_TWEAK_FILES || tweaks.some((tweak) => tweak.size > MAX_TWEAK_BYTES)) { setError("Each tweak must be 64 MB or smaller, with no more than 24 tweak files."); setStarting(false); setStatusModalOpen(false); return; }
    const formData = new FormData();
    formData.append("ipa", ipa);
    if (!useSaved) {
      if (certificate) formData.append("certificate", certificate);
      if (profile) formData.append("profile", profile);
      formData.append("password", password);
    } else formData.append("useSavedCertificate", "1");
    if (bundleId.trim()) formData.append("bundleId", bundleId.trim());
    if (appName.trim()) formData.append("appName", appName.trim());
    if (icon) formData.append("icon", icon);
    tweaks.forEach((tweak) => formData.append("tweaks", tweak));
    try {
      const response = await fetch("/api/sign", { method: "POST", body: formData });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error ?? "Signing could not be started.");
      setJob({ id: payload.jobId, status: "queued", progress: 2, stage: "queued", events: [], result: null, error: null });
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Signing could not be started."); } finally { setStarting(false); }
  };

  const clearAll = () => {
    setIpa(null); setCertificate(null); setProfile(null); setIcon(null); setTweaks([]); setPassword(""); setBundleId(""); setAppName(""); setUseSaved(false); setJob(null); setError(""); setResult(null); setStatusModalOpen(false);
  };

  return <div className="grid gap-7 xl:grid-cols-[minmax(0,1fr)_300px]">
    <section className="min-w-0">
      <PageHeader eyebrow="controlled IPA preparation" title="IPA Signer">Prepare a custom build with app-name metadata, optional tweak staging, OpenSSL validation, rcodesign signing, zsign certificate verification, and an app-name-aware OTA manifest.</PageHeader>
      <form onSubmit={submit} className="space-y-5">
        <div className={`panel-border relative overflow-hidden rounded-3xl bg-panel/80 p-4 sm:p-6 ${dragging ? "border-[#3197fd]/80 bg-[#3197fd]/[.08]" : ""}`} onDragOver={(event) => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(event) => { event.preventDefault(); setDragging(false); handleIpa(event.dataTransfer.files[0] ?? null); }}>
          <div className="mb-4 flex items-center justify-between"><div><div className="mono text-[10px] uppercase tracking-[.2em] text-white/35">01 / application package</div><h2 className="mt-2 text-lg font-semibold text-white">Drop your IPA here</h2></div><StatusChip tone="warning">required</StatusChip></div>
          <button type="button" onClick={() => document.getElementById("ipa-input")?.click()} className="group flex min-h-40 w-full flex-col items-center justify-center rounded-2xl border border-dashed border-white/15 bg-black/15 px-6 text-center transition hover:border-[#3197fd]/60 hover:bg-[#3197fd]/[.05] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3197fd]"><span className="mb-4 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04] text-white/45 transition group-hover:border-[#3197fd]/35 group-hover:text-[#3197fd]">{ipa ? <FileArchive size={21} /> : <UploadCloud size={21} />}</span><span className="text-sm font-medium text-white/78">{ipa ? ipa.name : "Choose a package or drag it into this bay"}</span><span className="mono mt-2 text-[10px] uppercase tracking-[.16em] text-white/28">{ipa ? `${formatBytes(ipa.size)} · ready to inspect` : ".ipa only · max 512 MB"}</span></button>
          <input id="ipa-input" className="file-input" type="file" accept=".ipa,application/octet-stream" onChange={(event) => handleIpa(event.target.files?.[0] ?? null)} />
        </div>
        {session && <label className="flex items-center gap-3 rounded-2xl border border-[#3197fd]/20 bg-[#3197fd]/[.05] p-4 text-sm text-white/70"><input type="checkbox" checked={useSaved} onChange={(event) => setUseSaved(event.target.checked)} className="accent-[#3197fd]" /> Use my saved signing set from Settings</label>}
        <section className="space-y-5 rounded-3xl border border-[#3197fd]/20 bg-white/[.03] p-4 sm:p-6">
          <div className="mono text-[10px] uppercase tracking-[.2em] text-[#3197fd]">02 / signing set</div>
          {useSaved ? <div className="rounded-3xl border border-emerald-300/20 bg-emerald-300/[.045] p-5"><div className="flex items-start gap-3"><CheckCircle2 className="mt-0.5 text-[#9ee1d1]" size={18} /><div><h2 className="font-semibold text-white">Saved signing set active</h2><p className="mt-1 text-sm leading-6 text-white/45">Certificate, provisioning profile, and password uploads are hidden while your saved signing set is selected.</p></div></div></div> : <div className="grid gap-5 rounded-3xl border border-white/10 bg-panel/55 p-4 sm:grid-cols-2 sm:p-6"><FileBay label="Apple certificate" accept=".p12,application/x-pkcs12" file={certificate} onChange={(file) => setCertificate(file as File | null)} icon={FileKey2} required /><FileBay label="Provisioning profile (.mobileprovision)" accept=".mobileprovision,application/octet-stream" file={profile} onChange={(file) => setProfile(file as File | null)} icon={ShieldCheck} required /><div className="sm:col-span-2"><label className="mb-2 block text-xs font-semibold text-white/60">Certificate password</label><div className="relative"><LockKeyhole size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-white/25" /><input value={password} onChange={(event) => setPassword(event.target.value)} type="password" autoComplete="off" placeholder="Enter password for the .p12 file" className={`${inputClass} pl-10`} /></div></div></div>}
          <div className="grid gap-5 rounded-3xl border border-white/10 bg-panel/55 p-4 sm:grid-cols-2 sm:p-6"><div><label className="mb-2 block text-xs font-semibold text-white/60">App name <span className="mono ml-1 text-[9px] uppercase text-white/25">optional</span></label><input value={appName} onChange={(event) => setAppName(event.target.value)} placeholder="What iOS should call this app" className={inputClass} /><p className="mt-2 text-[11px] leading-5 text-white/30">This becomes the OTA install name and does not expose your bundle ID.</p></div><div><label className="mb-2 block text-xs font-semibold text-white/60">Custom bundle ID <span className="mono ml-1 text-[9px] uppercase text-white/25">optional</span></label><div className="relative"><Fingerprint size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-white/25" /><input value={bundleId} onChange={(event) => setBundleId(event.target.value)} placeholder="com.custom.app" className={`${inputClass} mono pl-10 text-xs`} /></div></div><FileBay label="Custom app icon" accept=".png,image/png" file={icon} onChange={(file) => setIcon(file as File | null)} icon={FilePlus2} /></div>
          <div className="rounded-3xl border border-white/10 bg-panel/55 p-4 sm:p-6"><div className="mb-4 flex items-start justify-between gap-4"><div><div className="text-xs font-semibold text-white/60">Tweaks <span className="mono ml-1 text-[9px] uppercase text-white/25">optional</span></div><p className="mt-2 max-w-md text-xs leading-5 text-white/38">Inject validated Mach-O .dylib files from a .dylib or .deb package. Each injected library is re-signed with the app. Up to 24 files, 64 MB each.</p></div><span className="mono shrink-0 text-[10px] uppercase tracking-[.14em] text-white/25">{tweaks.length ? `${tweaks.length} loaded` : "none loaded"}</span></div><FileBay label="Add tweak files" accept=".dylib,.deb" file={tweaks} onChange={handleTweaks} icon={PackageCheck} multiple /></div>
        </section>
        {error && <div className="flex items-start gap-3 rounded-2xl border border-red-300/20 bg-red-300/[.06] px-4 py-3 text-sm text-red-100"><CircleAlert size={17} className="mt-0.5 shrink-0 text-red-300" /><span>{error}</span></div>}
        <div className="flex flex-col justify-between gap-4 border-t border-white/10 pt-5 sm:flex-row sm:items-center"><div className="flex items-center gap-2 text-xs text-white/35"><LockKeyhole size={14} className="text-[#9ee1d1]" /> Signed output is retained for one hour for download and OTA installation.</div><div className="flex items-center gap-3"><button type="button" className={quietButton} onClick={clearAll} disabled={processing}>Reset</button><button type="submit" className={violetButton} disabled={busy}><CloudUpload size={17} />{starting ? "Preparing signer…" : processing ? "Signing in progress" : "Sign Application"}<ArrowUpRight size={15} className="text-white/55" /></button></div></div>
      </form>
      {result && <ResultCard result={result} />}
      {(starting || job) && statusModalOpen && <SignStatusModal starting={starting} job={job} result={result} onClose={() => setStatusModalOpen(false)} />}
    </section>
  </div>;
}

function SignStatusModal({ starting, job, result, onClose }: { starting: boolean; job: SigningJob | null; result: SignResult | null; onClose: () => void }) {
  const progress = job?.progress ?? 0;
  const completed = job?.status === "completed" && result;
  const failed = job?.status === "failed";
  const events = job?.events ?? [];
  const terminal = !starting && (!job || failed || completed);
  return <div className="fixed inset-0 z-[80] grid place-items-center bg-black/75 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-label={completed ? "Signing complete" : failed ? "Signing failed" : "Signing progress"}><section className="flex max-h-[92svh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl border border-[#3197fd]/30 bg-[#081522] shadow-[0_30px_120px_rgba(0,0,0,.65)]"><div className="flex items-start justify-between gap-4 border-b border-white/10 px-4 py-4 sm:px-6"><div><div className="mono text-[10px] uppercase tracking-[.2em] text-[#3197fd]">{completed ? "signing complete" : failed ? "signing failed" : "signing console"}</div><h2 className="mt-2 text-lg font-semibold capitalize text-white sm:text-xl">{starting ? "Preparing signer…" : completed ? `${result.appName} is ready` : failed ? "Signing stopped" : job?.stage.replaceAll("_", " ") ?? "Preparing request"}</h2><p className="mt-1 text-sm text-white/45">{starting ? "Uploading your signing inputs and starting the worker." : completed ? "The signed IPA and OTA installation links are ready." : failed ? (job?.error ?? "The signing workflow could not complete.") : job?.events.at(-1)?.message ?? "Waiting for the first signer event…"}</p></div><button type="button" onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-white/10 bg-white/[.04] text-white/55 transition hover:border-[#3197fd]/50 hover:text-white" aria-label="Close signing status"><X size={17} /></button></div>{!completed && <div className="overflow-y-auto p-4 sm:p-6"><div className="h-2 overflow-hidden rounded-full bg-white/10"><div className={`h-full rounded-full transition-[width] duration-300 ${failed ? "bg-red-300" : "bg-gradient-to-r from-blue-500 to-cyan-300"}`} style={{ width: `${starting ? 4 : Math.max(2, progress)}%` }} /></div><div className="mt-2 flex justify-between text-[10px] text-white/30"><span className="mono uppercase tracking-[.16em]">{starting ? "starting" : job?.stage ?? "queued"}</span><span className="mono">{starting ? "—" : `${progress}%`}</span></div><details open={!terminal} className="mt-5 overflow-hidden rounded-2xl border border-[#9ee1d1]/15 bg-[#020609] shadow-inner"><summary className="cursor-pointer select-none border-b border-white/10 px-4 py-3 font-mono text-xs font-semibold text-[#9ee1d1]/85">Detailed signing console <span className="ml-1 text-white/35">({events.length} events)</span></summary><div role="log" aria-live="polite" className="max-h-[45svh] overflow-y-auto px-4 py-3 font-mono text-[11px] leading-6 text-slate-300">{events.length ? events.map((event, index) => <div key={`${event.timestamp}-${index}`} className="whitespace-pre-wrap"><span className="text-[#9ee1d1]">C:\XSIGNER&gt;</span> <span className={event.stage === "failed" ? "text-red-300" : "text-slate-300"}>{event.message}</span></div>) : <div className="text-slate-500"><span className="text-[#9ee1d1]">C:\XSIGNER&gt;</span> {starting ? "Preparing signing request…" : "Waiting for the first signer event…"}</div>}</div></details>{(failed || terminal) && <button type="button" onClick={onClose} className={`${quietButton} mt-5 w-full sm:w-auto`}>Close</button>}</div>}{completed && <div className="p-4 sm:p-6"><div className="rounded-2xl border border-[#9ee1d1]/25 bg-[#9ee1d1]/[.06] p-4 sm:p-5"><StatusChip tone="ready">Build ready</StatusChip><div className="mt-4 text-xl font-semibold text-white">{result.appName}</div><p className="mt-2 text-sm text-white/45">Version {result.version} · app name preserved for OTA installation.</p><div className="mt-5 flex flex-col gap-3 sm:flex-row"><a className={violetButton} href={result.downloadUrl}><Download size={16} /> Download IPA</a><a className={quietButton} href={result.otaUrl}><UploadCloud size={16} /> Install {result.appName}</a></div></div><button type="button" onClick={onClose} className={`${quietButton} mt-5 w-full sm:w-auto`}>Close</button></div>}</section></div>;
}

function ResultCard({ result }: { result: SignResult }) {
  const domain = new URL(result.manifestUrl).host;
  return <div className="mt-8 rounded-3xl border border-[#9ee1d1]/25 bg-[#9ee1d1]/[.06] p-5"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div><StatusChip tone="ready">Build ready</StatusChip><h2 className="mt-4 text-xl font-semibold text-white">{result.appName} is ready to install.</h2><p className="mt-2 text-sm text-white/45">App name: {result.appName} · Version {result.version}</p><p className="mt-1 text-xs text-white/30">Bundle ID is retained as signed metadata and is not used as the OTA install label.</p></div><PackageCheck size={28} className="text-[#9ee1d1]" /></div><div className="mt-6 flex flex-col gap-3 sm:flex-row"><a className={violetButton} href={result.downloadUrl}><Download size={16} /> Download IPA</a><a className={quietButton} href={result.otaUrl}><UploadCloud size={16} /> Install {result.appName} via OTA</a></div><div className="mt-6 flex items-center gap-4 border-t border-white/10 pt-5"><div className="rounded-xl bg-white p-2"><QRCodeSVG value={result.otaUrl} size={88} /></div><div><div className="flex items-center gap-2 text-sm font-semibold text-white"><QrCode size={15} className="text-[#9ee1d1]" /> Scan to install {result.appName}</div><p className="mt-1 max-w-sm text-xs leading-5 text-white/40">On iPhone, iOS will identify <strong className="font-semibold text-white/70">{domain}</strong> as the site requesting installation of <strong className="font-semibold text-white/70">{result.appName}</strong>.</p></div></div></div>;
}

function MetadataCard({ title, icon: Icon, status, items }: { title: string; icon: LucideIcon; status: string; items: Array<[string, string]> }) { return <section className={panelClass}><div className="flex items-center justify-between gap-3"><h2 className="flex items-center gap-2 font-semibold text-white"><Icon size={17} className="text-[#3197fd]" />{title}</h2><StatusChip tone={status === "Valid" ? "ready" : "warning"}>{status}</StatusChip></div><div className="mt-5 grid gap-4 sm:grid-cols-2">{items.map(([label, value]) => <div key={label} className="min-w-0"><div className="mono text-[9px] uppercase tracking-[.14em] text-white/30">{label}</div><div className="mt-1 break-words text-sm text-white/75">{value || "—"}</div></div>)}</div></section>; }
function CertificateCheckerPage() {
  const [mode, setMode] = useState<"p12" | "profile" | "dual">("dual"); const [p12, setP12] = useState<File | null>(null); const [profile, setProfile] = useState<File | null>(null); const [password, setPassword] = useState(""); const [error, setError] = useState(""); const [result, setResult] = useState<InspectionResult | null>(null); const [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent) => { event.preventDefault(); setError(""); setResult(null); setBusy(true); const form = new FormData(); form.append("mode", mode); if (p12) form.append("p12", p12); if (profile) form.append("profile", profile); if (password) form.append("password", password); try { const response = await fetch("/api/certificates/check", { method: "POST", body: form }); const payload = await response.json(); if (!response.ok) throw new Error(payload.error ?? "The signing files could not be inspected."); setResult(payload); } catch (caught) { setError(caught instanceof Error ? caught.message : "The signing files could not be inspected."); } finally { setBusy(false); } };
  return <div className="mx-auto max-w-5xl"><PageHeader eyebrow="first-party inspection / openssl" title="Certificate checker">Inspect P12 certificate identity and provisioning profile metadata locally. Passwords are used only for this request and are never included in responses.</PageHeader><form onSubmit={submit} className="space-y-5"><section className={panelClass}><div className="flex flex-wrap gap-2">{(["dual", "p12", "profile"] as const).map((item) => <button key={item} type="button" className={item === mode ? violetButton : quietButton} onClick={() => setMode(item)}>{item === "dual" ? "Dual check" : item === "p12" ? "P12 only" : "Profile only"}</button>)}</div><div className="mt-6 grid gap-5 sm:grid-cols-2"><FileBay label="P12 certificate" accept=".p12,application/x-pkcs12" file={p12} onChange={(item) => setP12(item as File | null)} icon={KeyRound} required={mode !== "profile"} /><FileBay label="Mobileprovision profile" accept=".mobileprovision,application/octet-stream" file={profile} onChange={(item) => setProfile(item as File | null)} icon={ShieldCheck} required={mode !== "p12"} /><div className="sm:col-span-2"><label className="mb-2 block text-xs font-semibold text-white/60">P12 password</label><input className={inputClass} type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Used only during this inspection" /></div></div></section>{error && <div className="rounded-2xl border border-red-300/20 bg-red-300/[.06] px-4 py-3 text-sm text-red-100">{error}</div>}<button className={`${violetButton} w-full`} disabled={busy} type="submit">{busy ? <LoaderCircle size={17} className="animate-spin" /> : <ShieldCheck size={17} />}{busy ? "Inspecting" : "Inspect signing set"}</button></form>{result && <div className="mt-6 grid gap-5 lg:grid-cols-2">{result.p12 && <MetadataCard title="P12 certificate" icon={KeyRound} status={result.p12.status} items={[["Common name", result.p12.subject?.CN || "—"], ["Organization", result.p12.subject?.O || "—"], ["Valid from", result.p12.validFrom || "—"], ["Expires", result.p12.expiresAt || "—"], ["Issuer", result.p12.issuer?.CN || "—"], ["SHA-256", result.p12.fingerprint || "—"]]} />}{result.mobileprovision && <MetadataCard title="Provisioning profile" icon={ShieldCheck} status={result.mobileprovision.status} items={[["Name", result.mobileprovision.name], ["Team", `${result.mobileprovision.teamName} ${result.mobileprovision.teamIdentifier}`], ["App ID", result.mobileprovision.applicationIdentifier || "—"], ["UUID", result.mobileprovision.uuid || "—"], ["Expires", result.mobileprovision.expiration], ["Debug entitlement", result.mobileprovision.getTaskAllow ? "Enabled" : "Disabled"]]} />}</div>}</div>;
}
function P12PasswordPage() {
  const [file, setFile] = useState<File | null>(null); const [oldPassword, setOldPassword] = useState(""); const [newPassword, setNewPassword] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false); const [download, setDownload] = useState<{ url: string; name: string } | null>(null);
  const submit = async (event: FormEvent) => { event.preventDefault(); if (!file) { setError("Choose a .p12 certificate first."); return; } setBusy(true); setError(""); setDownload(null); const form = new FormData(); form.append("p12", file); form.append("oldPassword", oldPassword); form.append("newPassword", newPassword); try { const response = await fetch("/api/certificates/p12-password", { method: "POST", body: form }); if (!response.ok) { const payload = await response.json(); throw new Error(payload.error ?? "The P12 password could not be changed."); } const blob = await response.blob(); setDownload({ url: URL.createObjectURL(blob), name: `${file.name.replace(/\.p12$/i, "")}-new-password.p12` }); } catch (caught) { setError(caught instanceof Error ? caught.message : "The P12 password could not be changed."); } finally { setBusy(false); } };
  return <div className="mx-auto max-w-3xl"><PageHeader eyebrow="first-party utility / openssl" title="P12 password changer">Re-export a P12 with a new password locally. The old and new passwords are used only for this request and are never persisted or returned.</PageHeader><form onSubmit={submit} className="space-y-5"><section className={panelClass}><FileBay label="P12 certificate" accept=".p12,application/x-pkcs12" file={file} onChange={(item) => setFile(item as File | null)} icon={KeyRound} required /><div className="mt-5 grid gap-5 sm:grid-cols-2"><div><label className="mb-2 block text-xs font-semibold text-white/60">Current password</label><input className={inputClass} type="password" value={oldPassword} onChange={(event) => setOldPassword(event.target.value)} placeholder="Blank if none" /></div><div><label className="mb-2 block text-xs font-semibold text-white/60">New password</label><input className={inputClass} type="password" required value={newPassword} onChange={(event) => setNewPassword(event.target.value)} placeholder="1–256 characters" /></div></div></section>{error && <div className="rounded-2xl border border-red-300/20 bg-red-300/[.06] px-4 py-3 text-sm text-red-100">{error}</div>}<button className={`${violetButton} w-full`} disabled={busy} type="submit">{busy ? <LoaderCircle size={17} className="animate-spin" /> : <LockKeyhole size={17} />}{busy ? "Re-encrypting" : "Update certificate password"}</button></form>{download && <section className="mt-6 rounded-3xl border border-[#9ee1d1]/25 bg-[#9ee1d1]/[.06] p-5"><StatusChip tone="ready">New P12 ready</StatusChip><h2 className="mt-4 text-xl font-semibold text-white">Download the re-encrypted certificate.</h2><p className="mt-2 text-sm text-white/45">The new password is not stored by Xsigner. Keep it in your password manager.</p><a className={`${violetButton} mt-5`} href={download.url} download={download.name}><Download size={16} /> Download P12</a></section>}</div>;
}
function FreeCertificatesPage() {
  const [status, setStatus] = useState("signed"); const [amount, setAmount] = useState("5"); const [items, setItems] = useState<Certificate[]>([]); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  const load = async () => { setLoading(true); setError(""); try { const response = await fetch(`/api/free-certificates?status=${status}&amount=${amount}`); const payload = await response.json(); if (!response.ok) throw new Error(payload.error ?? "Certificate list unavailable."); setItems(payload.certificates ?? []); } catch (caught) { setError(caught instanceof Error ? caught.message : "Certificate list unavailable."); } finally { setLoading(false); } };
  useEffect(() => { void load(); }, [status, amount]);
  return <div className="mx-auto max-w-6xl"><PageHeader eyebrow="nexcerts / sideloading.net" title="Free certificates">List and filter certificates from the NexCerts repository. Data is synced every 30 minutes from GitHub. Use the download endpoints only with certificates and profiles you are authorized to use.</PageHeader><div><section className={panelClass}><div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><div className="mono text-[10px] uppercase tracking-[.2em] text-[#3197fd]">live directory</div><h2 className="mt-2 text-xl font-semibold text-white">Certificate list</h2></div><div className="flex gap-2"><select className={`${inputClass} min-w-0`} value={status} onChange={(event) => setStatus(event.target.value)}><option value="all">all</option><option value="signed">signed</option><option value="revoked">revoked</option><option value="missingP12">missingP12</option></select><select className={`${inputClass} w-24`} value={amount} onChange={(event) => setAmount(event.target.value)}><option value="5">5</option><option value="10">10</option><option value="25">25</option></select></div></div>{error && <div className="mt-5 rounded-2xl border border-amber-300/20 bg-amber-300/[.06] px-4 py-3 text-sm text-amber-100">{error}</div>}<div className="mt-5 space-y-3">{loading ? <div className="flex items-center gap-2 rounded-2xl border border-white/10 p-5 text-sm text-white/45"><LoaderCircle size={17} className="animate-spin" /> Loading NexCerts…</div> : items.length ? items.map((item) => <div key={item.id} className="rounded-2xl border border-white/10 bg-black/15 p-4"><div className="flex items-start justify-between gap-3"><div className="min-w-0"><div className="truncate text-sm font-semibold text-white">{item.nickname || item.name}</div><div className="mt-1 text-xs text-white/35">{item.name}</div></div><StatusChip tone={item.status.includes("Signed") ? "ready" : item.status.includes("Revoked") ? "danger" : "warning"}>{item.status.replace(/[✅❌]/g, "").trim()}</StatusChip></div><div className="mt-4 grid gap-2 text-xs text-white/45 sm:grid-cols-2"><span>Valid from: {item.valid_from}</span><span>Valid to: {item.valid_to}</span></div><div className="mt-4 flex flex-wrap gap-2"><a className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65 hover:border-[#3197fd]/50" href={`https://sideloading.net/api/certificates/download/${item.id}/cert.zip`} target="_blank" rel="noreferrer"><Download size={13} /> cert.zip</a><a className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-3 py-2 text-xs text-white/65 hover:border-[#3197fd]/50" href={`https://sideloading.net/api/certificates/download/${item.id}/cert.mobileprovision`} target="_blank" rel="noreferrer"><Download size={13} /> profile</a></div></div>) : <div className="rounded-2xl border border-dashed border-white/10 px-4 py-12 text-center text-sm text-white/35">No certificates returned for this filter.</div>}</div><button className={`${quietButton} mt-5 w-full`} type="button" onClick={() => void load()} disabled={loading}><RefreshCw size={15} className={loading ? "animate-spin" : ""} /> Refresh list</button></section></div></div>;
}

function AuthPage({ onAuth }: { onAuth: (user: any) => void }) { const [mode,setMode]=useState<"signin"|"signup">("signin"); const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const submit=async(e:FormEvent)=>{e.preventDefault();setError("");const r=await fetch(`/api/auth/${mode}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});const p=await r.json();if(!r.ok){setError(p.error||"Authentication failed.");return;}onAuth(p.user);}; return <div className="mx-auto max-w-md"><PageHeader eyebrow="private workspace" title={mode === "signin" ? "Sign in" : "Create account"}>Username and password only—no email or social account is required.</PageHeader><form onSubmit={submit} className={panelClass}><label className="mb-2 block text-xs text-white/60">Username</label><input className={inputClass} value={username} onChange={e=>setUsername(e.target.value)} autoComplete="username"/><label className="mb-2 mt-5 block text-xs text-white/60">Password</label><input className={inputClass} type="password" value={password} onChange={e=>setPassword(e.target.value)} autoComplete={mode === "signin" ? "current-password" : "new-password"}/>{error&&<p className="mt-4 text-sm text-red-200">{error}</p>}<button className={`${violetButton} mt-5 w-full`}><UserRound size={16}/>{mode === "signin" ? "Sign in" : "Sign up"}</button><button type="button" className={`${quietButton} mt-3 w-full`} onClick={()=>setMode(mode === "signin" ? "signup" : "signin")}>{mode === "signin" ? "Create a new account" : "I already have an account"}</button></form></div>; }
function SettingsPage({ user }: { user: any }) {
  const [p12, setP12] = useState<File | null>(null);
  const [profile, setProfile] = useState<File | null>(null);
  const [avatar, setAvatar] = useState<File | null>(null);
  const [password, setPassword] = useState("");
  const [saved, setSaved] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [avatarPreview, setAvatarPreview] = useState("");

  useEffect(() => {
    fetch("/api/settings").then(async response => {
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not load settings.");
      setSaved(data.savedCertificate);
    }).catch(cause => setError(cause instanceof Error ? cause.message : "Could not load settings.")).finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    if (!avatar) { setAvatarPreview(""); return; }
    const url = URL.createObjectURL(avatar);
    setAvatarPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [avatar]);

  const selectAvatar = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 4 * 1024 * 1024) {
      setError("Choose a PNG, JPEG, or WebP image no larger than 4 MB.");
      return;
    }
    setError(""); setNotice(""); setAvatar(file);
  };
  const save = async () => {
    setNotice(""); setError("");
    if ((p12 && !profile) || (!p12 && profile)) { setError("Choose both a P12 certificate and a mobileprovision profile to replace the saved signing set."); return; }
    if (!p12 && !profile && !avatar) { setError("Choose a profile picture or a complete signing set first."); return; }
    setSaving(true); setProgress(8);
    try {
      const form = new FormData();
      if (avatar) form.append("avatar", avatar, avatar.name);
      if (p12) form.append("p12", p12, p12.name);
      if (profile) form.append("profile", profile, profile.name);
      form.append("password", password);
      setProgress(35);
      const response = await fetch("/api/settings", { method: "POST", body: form });
      setProgress(78);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Settings could not be saved.");
      setSaved(data.savedCertificate ?? saved);
      setP12(null); setProfile(null); setAvatar(null); setPassword(""); setProgress(100);
      setNotice(data.savedCertificate ? "Signing set inspected and saved securely." : "Profile picture saved securely.");
      window.setTimeout(() => setProgress(null), 500);
    } catch (cause) {
      setProgress(null);
      setError(cause instanceof Error ? cause.message : "Settings could not be saved. Check your connection and retry.");
    } finally { setSaving(false); }
  };
  const removeSaved = async () => {
    if (!saved || !window.confirm("Delete your saved P12, provisioning profile, and saved password? This cannot be undone.")) return;
    setSaving(true); setNotice(""); setError("");
    try {
      const response = await fetch("/api/settings", { method: "DELETE", headers: { "X-Xsigner-Confirm": "delete-saved-certificate" } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Saved signing set could not be deleted.");
      setSaved(null); setP12(null); setProfile(null); setPassword(""); setNotice("Saved signing set deleted.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Saved signing set could not be deleted."); }
    finally { setSaving(false); }
  };
  const currentAvatar = avatarPreview || user?.avatarUrl || user?.discordAvatarUrl || "";
  const hasChanges = Boolean(avatar || p12 || profile);

  return <div className="mx-auto max-w-4xl space-y-6 pb-12">
    <header className="space-y-2"><div className="inline-flex items-center gap-2 rounded-full border border-sky-300/20 bg-sky-300/[.06] px-3 py-1 text-[10px] font-bold uppercase tracking-[.16em] text-sky-200"><UserRound size={14} />Account settings</div><h1 className="text-3xl font-extrabold text-white">Settings</h1><p className="text-sm text-slate-400">Manage your profile and securely save credentials for reuse in IPA Signer.</p></header>
    {notice && <div role="status" className="flex items-center gap-2 rounded-xl border border-emerald-300/20 bg-emerald-300/[.06] px-4 py-3 text-sm text-emerald-200"><CheckCircle2 size={16} />{notice}</div>}
    {error && <div role="alert" className="rounded-xl border border-rose-300/20 bg-rose-300/[.06] px-4 py-3 text-sm text-rose-200">{error}</div>}

    <section className="rounded-2xl border border-white/[.08] bg-[#0b1b2b]/90 p-5 sm:p-6"><div className="flex min-w-0 items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-sky-400/10 text-sky-200"><UserRound size={20} /></div><div className="min-w-0 flex-1"><h2 className="text-base font-bold text-white">Profile</h2><p className="break-words text-xs text-slate-400">Signed in as @{user?.username || "xsigner"}. Upload a picture to override your current avatar.</p></div></div><div className="mt-5 flex flex-col gap-5 sm:flex-row sm:items-center"><div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-full border border-sky-300/25 bg-sky-400/10">{currentAvatar ? <img src={currentAvatar} alt="Profile" className="h-full w-full object-cover" /> : <div className="grid h-full w-full place-items-center text-2xl font-bold text-sky-200">{user?.username?.[0]?.toUpperCase() || "X"}</div>}<label className="absolute inset-x-0 bottom-0 grid h-7 cursor-pointer place-items-center bg-slate-950/80 text-white" title="Choose profile picture"><UploadCloud size={15} /><input type="file" accept="image/png,image/jpeg,image/webp" onChange={selectAvatar} className="sr-only" /></label></div><div className="min-w-0 flex-1 space-y-3"><div className="flex flex-wrap gap-2 text-xs"><span className="rounded-full border border-white/10 px-2.5 py-1 text-slate-400">Username sign-in</span>{user?.isOwner && <span className="rounded-full border border-sky-300/20 bg-sky-300/[.06] px-2.5 py-1 text-sky-200">Owner account</span>}</div><p className="text-xs leading-5 text-slate-500">Your profile picture is stored with your account and shown in the workspace navigation.</p></div></div></section>

    <section className="rounded-2xl border border-cyan-300/15 bg-[#0b1b2b]/90 p-5 sm:p-6"><div className="flex min-w-0 items-center gap-3"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-cyan-300/10 text-cyan-200"><FileKey2 size={20} /></div><div className="min-w-0 flex-1"><h2 className="text-base font-bold text-white">Saved IPA signing set</h2><p className="break-words text-xs text-slate-400">Save a P12 and provisioning profile once, then reuse them from the IPA Signer.</p></div></div>
      <div className="mt-5 grid min-w-0 gap-4 sm:grid-cols-2"><label className="block space-y-2 text-xs font-medium text-slate-300">P12 certificate<input className={`${inputClass} file:mr-3 file:rounded-md file:border-0 file:bg-sky-500 file:px-2 file:py-1 file:text-xs file:font-semibold file:text-white`} type="file" accept=".p12" onChange={event => setP12(event.target.files?.[0] || null)} /><span className="block text-[10px] text-slate-500">{p12?.name || saved?.p12Name || "Certificate file · .p12"}</span></label><label className="block space-y-2 text-xs font-medium text-slate-300">Mobileprovision profile<input className={`${inputClass} file:mr-3 file:rounded-md file:border-0 file:bg-sky-500 file:px-2 file:py-1 file:text-xs file:font-semibold file:text-white`} type="file" accept=".mobileprovision" onChange={event => setProfile(event.target.files?.[0] || null)} /><span className="block text-[10px] text-slate-500">{profile?.name || saved?.profileName || "Provisioning profile · .mobileprovision"}</span></label></div>
      <div className="mt-4 rounded-xl border border-white/[.07] bg-white/[.025] p-4"><label className="block space-y-2 text-xs font-medium text-slate-300">P12 password <span className="font-normal text-slate-500">(leave blank for passwordless certificates)</span><input className={inputClass} type="password" autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter certificate password, if any" /></label></div>
      <div className="mt-4 flex items-start gap-2 rounded-xl border border-sky-300/10 bg-sky-300/[.04] p-3 text-[11px] leading-5 text-slate-400"><LockKeyhole size={16} className="mt-0.5 shrink-0 text-sky-300" /><span>Signing files stay private to your account and are only available to the saved-certificate option inside IPA Signer.</span></div>
      {saved && <div className="mt-4 min-w-0 rounded-xl border border-emerald-300/15 bg-emerald-300/[.035] p-3.5 text-xs sm:p-4"><div className="flex min-w-0 flex-wrap items-start justify-between gap-3"><div className="min-w-0"><span className="inline-flex items-center gap-1.5 font-semibold text-emerald-100"><CheckCircle2 size={14} />Saved signing identity</span><p className="mt-2 break-words text-sm font-semibold text-white">{saved.p12Organization || "Organization unavailable"}</p><p className="mt-1 break-words text-[11px] text-slate-400">{saved.p12Name} + {saved.profileName}</p></div><StatusChip tone={saved.signedStatus === "Signed" ? "ready" : "warning"}>{saved.signedStatus}</StatusChip></div><div className="mt-3 grid min-w-0 gap-3 border-t border-white/[.07] pt-3 sm:grid-cols-2"><div className="min-w-0"><span className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">P12 status</span><p className="mt-1 text-slate-200">{saved.p12Status}</p></div><div className="min-w-0"><span className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">P12 expiration</span><p className="mt-1 break-words text-slate-200">{saved.p12ExpiresAt || "Not available"}</p></div><div className="min-w-0"><span className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Profile status</span><p className="mt-1 text-slate-200">{saved.profileStatus}</p></div><div className="min-w-0"><span className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">Profile expiration</span><p className="mt-1 break-words text-slate-200">{saved.profileExpiresAt || "Not available"}</p></div></div><p className="mt-3 text-[11px] leading-5 text-slate-500">Revocation status: {saved.revocationStatus}. Local validation confirms the saved files are signed and parseable.</p><button type="button" onClick={() => void removeSaved()} disabled={saving} className="mt-4 inline-flex items-center gap-2 rounded-lg border border-red-300/25 bg-red-300/[.06] px-3 py-2 text-xs font-semibold text-red-100 transition hover:bg-red-300/[.12] disabled:opacity-50"><X size={14} />Delete saved signing set</button></div>}
    </section>
    {saving && <div role="status" aria-live="polite" className="space-y-2 rounded-xl border border-sky-300/10 bg-sky-300/[.035] px-4 py-3"><div className="flex items-center justify-between text-xs text-slate-300"><span className="flex items-center gap-2"><UploadCloud size={15} className="text-sky-200" />Saving securely…</span><span className="mono tabular-nums text-sky-200">{progress ?? 0}%</span></div><div className="h-2 overflow-hidden rounded-full bg-black/40"><div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-300 transition-[width] duration-150" style={{ width: `${progress ?? 0}%` }} /></div></div>}
    <div className="flex justify-end"><button disabled={saving || !hasChanges} onClick={() => void save()} className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 px-5 py-3 text-sm font-bold text-[#04111f] shadow-lg shadow-sky-950/30 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto">{saving ? <><LoaderCircle size={16} className="animate-spin" />Saving securely…</> : <><Settings size={16} />Save settings</>}</button></div>
  </div>;
}

function OwnerPage() {
  const [data, setData] = useState<any>(null); const [message, setMessage] = useState(""); const [busy, setBusy] = useState(false);
  const load = async () => { try { const response = await fetch("/api/owner", { cache: "no-store" }); const payload = await response.json(); if (!response.ok) throw new Error(payload.error || "Owner data could not be loaded."); setData(payload); } catch (cause) { setMessage(cause instanceof Error ? cause.message : "Owner data could not be loaded."); } };
  useEffect(() => { void load(); }, []);
  const cleanup = async (action: "cleanup-expired-sessions" | "cleanup-expired-outputs") => { const label = action === "cleanup-expired-sessions" ? "expired sessions" : "expired signed outputs"; if (!window.confirm(`Delete ${label} now? Active data is not affected.`)) return; setBusy(true); setMessage(""); try { const response = await fetch("/api/owner", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action }) }); const payload = await response.json(); if (!response.ok) throw new Error(payload.error || "Maintenance action failed."); setMessage(`Deleted ${payload.deleted ?? 0} ${label}.`); await load(); } catch (cause) { setMessage(cause instanceof Error ? cause.message : "Maintenance action failed."); } finally { setBusy(false); } };
  const summary = data?.dashboard?.summary ?? {};
  const cards = [["Accounts", summary.users ?? "—", UserRound, "Registered Xsigner users"], ["Saved certificates", summary.certificates ?? "—", FileKey2, "Reusable signing sets"], ["Signing jobs", summary.jobs ?? "—", Activity, `${summary.completedJobs ?? 0} completed · ${summary.failedJobs ?? 0} failed`], ["Live outputs", summary.availableOutputs ?? "—", PackageCheck, "Download and OTA files in retention"]] as const;
  return <div className="mx-auto max-w-6xl space-y-5"><PageHeader eyebrow="owner only / operations" title="Owner console">Live project information, signer health, protected API state, and durable activity records. Access requires a signed-in account from the exact owner IP.</PageHeader>{message && <div className="rounded-xl border border-amber-300/20 bg-amber-300/[.06] px-4 py-3 text-sm text-amber-100">{message}</div>}<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map(([label, value, Icon, detail]) => <section key={label} className={panelClass}><Icon className="text-[#3197fd]" size={20} /><div className="mt-4 text-xs uppercase tracking-wider text-white/35">{label}</div><div className="mt-1 text-2xl font-semibold text-white">{value}</div><p className="mt-2 text-xs leading-5 text-white/40">{detail}</p></section>)}</div><div className="grid gap-5 lg:grid-cols-[1.3fr_.7fr]"><section className={panelClass}><div className="flex items-center justify-between gap-4"><div><h2 className="text-lg font-semibold text-white">Signing activity</h2><p className="mt-1 text-sm text-white/40">Recent browser and Discord API signing jobs.</p></div><StatusChip tone={data?.owner ? "ready" : "warning"}>{data?.owner ? "verified" : "loading"}</StatusChip></div><div className="mt-5 overflow-x-auto"><table className="w-full min-w-[640px] text-left text-xs"><thead className="border-b border-white/10 text-[10px] uppercase tracking-[.14em] text-white/30"><tr><th className="pb-3 font-medium">Source</th><th className="pb-3 font-medium">App</th><th className="pb-3 font-medium">Stage</th><th className="pb-3 font-medium">Status</th><th className="pb-3 font-medium">Updated</th></tr></thead><tbody>{data?.dashboard?.recentJobs?.length ? data.dashboard.recentJobs.map((job: any) => <tr key={job.id} className="border-b border-white/[.06] text-white/55"><td className="py-3 capitalize">{job.source}</td><td className="max-w-40 truncate py-3 text-white/75">{job.app_name || "—"}</td><td className="py-3 mono text-[10px] text-white/40">{job.stage}</td><td className="py-3"><StatusChip tone={job.status === "completed" ? "ready" : job.status === "failed" ? "danger" : "warning"}>{job.status}</StatusChip></td><td className="py-3 text-white/35">{job.updated_at ? new Date(job.updated_at).toLocaleString() : "—"}</td></tr>) : <tr><td colSpan={5} className="py-10 text-center text-white/35">No signing activity has been recorded yet.</td></tr>}</tbody></table></div></section><section className={panelClass}><h2 className="text-lg font-semibold text-white">Runtime & API</h2><div className="mt-5 space-y-3 text-sm"><div className="rounded-xl border border-white/10 bg-black/15 p-3"><div className="text-white/35">OpenSSL</div><div className="mt-1 font-medium text-white/80">{data?.signer?.openssl?.status ?? "checking"}</div><div className="mt-1 text-[11px] text-white/35">{data?.signer?.openssl?.detail}</div></div><div className="rounded-xl border border-white/10 bg-black/15 p-3"><div className="text-white/35">rcodesign</div><div className="mt-1 font-medium text-white/80">{data?.signer?.rcodesign?.status ?? "checking"}</div><div className="mt-1 text-[11px] text-white/35">{data?.signer?.rcodesign?.detail}</div></div><div className="rounded-xl border border-white/10 bg-black/15 p-3"><div className="text-white/35">zsign cross-check</div><div className="mt-1 font-medium text-white/80">{data?.signer?.zsign?.status ?? "checking"}</div><div className="mt-1 text-[11px] text-white/35">{data?.signer?.zsign?.detail}</div></div><div className="rounded-xl border border-white/10 bg-black/15 p-3"><div className="text-white/35">Discord bearer API</div><div className="mt-1 font-medium text-white/80">{data?.security?.discordApi ?? "checking"}</div><div className="mt-1 text-[11px] text-white/35">Credential state only; token is never shown.</div></div></div><div className="mt-5 border-t border-white/10 pt-5"><div className="text-xs font-semibold uppercase tracking-[.14em] text-white/35">Maintenance</div><div className="mt-3 grid gap-2"><button type="button" onClick={() => void cleanup("cleanup-expired-sessions")} disabled={busy} className={quietButton}><X size={15} />Clean expired sessions</button><button type="button" onClick={() => void cleanup("cleanup-expired-outputs")} disabled={busy} className={quietButton}><X size={15} />Clean expired outputs</button></div></div></section></div><section className={panelClass}><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-lg font-semibold text-white">Protected surface</h2><p className="mt-1 text-sm text-white/40">Owner access is enforced by authenticated session and trusted edge IP.</p></div><StatusChip tone="warning">{data?.security?.ownerIp || "IP policy"}</StatusChip></div><div className="mt-4 grid gap-3 sm:grid-cols-3">{[["Discord sign", data?.discordApi?.sign], ["Discord health", data?.discordApi?.health], ["Discord jobs", data?.discordApi?.jobs]].map(([label, endpoint]) => <div key={String(label)} className="rounded-xl border border-white/10 bg-black/15 p-3"><div className="text-xs font-semibold text-white/75">{label}</div><div className="mono mt-2 break-all text-[10px] text-white/35">{String(endpoint || "—")}</div></div>)}</div></section></div>;
}

function CodeBlock({ children }: { children: string }) { return <pre className="mono mt-4 overflow-x-auto rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs leading-6 text-slate-600">{children}</pre>; }

function DiscordApiPage() {
  return <div className="mx-auto max-w-6xl"><PageHeader eyebrow="private bot integration / API-key-only" title="Discord API reference">Complete request, response, authentication, polling, error, and compatibility documentation for the deployed Discord signing API. Every endpoint uses the API key only; client IP is not used for Discord authorization.</PageHeader><div className="space-y-5">
    <section className={panelClass}><div className="flex items-start gap-3"><Bot className="mt-1 text-[#3197fd]"/><div><h2 className="text-xl font-semibold">Authentication</h2><p className="mt-2 text-sm leading-6 text-slate-500">Send the configured key on every Discord API request. The API accepts requests from any client IP when the bearer key is correct. Do not put the key in browser code, embeds, or public repositories.</p></div></div><CodeBlock>{`Authorization: Bearer $XSIGNER_DISCORD_API_KEY
Accept: application/json`}</CodeBlock><div className="mt-4 grid gap-3 sm:grid-cols-3"><div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600"><strong className="text-slate-900">401</strong><br />Missing Authorization header</div><div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600"><strong className="text-slate-900">403</strong><br />Invalid bearer key</div><div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600"><strong className="text-slate-900">503</strong><br />Key not configured</div></div></section>
    <section className={panelClass}><h2 className="text-xl font-semibold">POST /api/v1/discord/sign</h2><p className="mt-2 text-sm leading-6 text-slate-500">Starts an asynchronous signing job. Content type must be multipart/form-data. The request returns quickly with HTTP 202; poll the returned status URL instead of waiting on the upload request.</p><CodeBlock>{`curl -X POST https://xsigner-hncbblmn.manus.space/api/v1/discord/sign \
  -H "Authorization: Bearer $XSIGNER_DISCORD_API_KEY" \
  -F ipa=@app.ipa \
  -F certificate=@certificate.p12 \
  -F profile=@profile.mobileprovision \
  -F password=YOUR_P12_PASSWORD \
  -F bundleId=com.example.app \
  -F appName="My App" \
  -F icon=@icon.png \
  -F tweaks=@tweak.deb \
  -F tweaks=@tweak.dylib`}</CodeBlock><h3 className="mt-5 font-semibold text-slate-900">Multipart fields</h3><div className="mt-3 overflow-x-auto"><table className="w-full min-w-[680px] text-left text-xs text-slate-600"><thead className="border-b border-slate-200 text-[10px] uppercase tracking-[.14em] text-slate-400"><tr><th className="pb-2">Field</th><th className="pb-2">Type</th><th className="pb-2">Required</th><th className="pb-2">Behavior</th></tr></thead><tbody>{[["ipa","file .ipa","yes","IPA package; max 512 MB"],["certificate / cert / p12","file .p12","yes","Apple signing certificate; max 16 MB"],["profile / provision / mobileprovision","file .mobileprovision","yes","Provisioning profile; max 16 MB"],["password / p12_password / p12Password","text","yes","P12 password; blank is allowed"],["bundleId / bundle_id","text","no","Letters, numbers, periods, hyphens"],["appName / app_name","text","no","1–80 printable characters; used for OTA label"],["icon","file .png","no","Custom app icon; max 16 MB"],["tweaks","file .dylib or .deb","no, repeatable","Up to 24 files; each max 64 MB"]].map(([field,type,required,behavior]) => <tr key={field} className="border-b border-slate-100"><td className="py-2 pr-3 font-mono text-[11px] text-slate-800">{field}</td><td className="py-2 pr-3">{type}</td><td className="py-2 pr-3">{required}</td><td className="py-2">{behavior}</td></tr>)}</tbody></table></div><CodeBlock>{`{
  "success": true,
  "jobId": "sign_abc123",
  "job_id": "sign_abc123",
  "status": "queued",
  "progress": 2,
  "stage": "queued",
  "events": [{"stage":"queued","message":"Preparing signing request…","progress":2}],
  "message": "Request accepted",
  "statusUrl": "https://xsigner-hncbblmn.manus.space/api/v1/discord/jobs/sign_abc123",
  "status_url": "https://xsigner-hncbblmn.manus.space/api/v1/discord/jobs/sign_abc123",
  "progressUrl": "https://xsigner-hncbblmn.manus.space/api/v1/discord/jobs/sign_abc123/progress",
  "progress_url": "https://xsigner-hncbblmn.manus.space/api/v1/discord/jobs/sign_abc123/progress",
  "poll_after_ms": 1000,
  "updatedAt": "2026-10-08T10:00:00.000Z"
}`}</CodeBlock></section>
    <section className={panelClass}><h2 className="text-xl font-semibold">GET /api/v1/discord/jobs/:job_id</h2><h2 className="mt-5 text-xl font-semibold">GET /api/v1/discord/jobs/:job_id/progress</h2><p className="mt-2 text-sm leading-6 text-slate-500">Both endpoints use the same key-only authorization and return the current job object. Poll every second while status is queued or processing. The job is only visible to the bearer key that created it.</p><CodeBlock>{`curl -H "Authorization: Bearer $XSIGNER_DISCORD_API_KEY" \
  https://xsigner-hncbblmn.manus.space/api/v1/discord/jobs/sign_abc123`}</CodeBlock><h3 className="mt-5 font-semibold text-slate-900">Processing response</h3><CodeBlock>{`{
  "success": true,
  "jobId": "sign_abc123",
  "status": "processing",
  "progress": 62,
  "stage": "signing",
  "events": [
    {"stage":"queued","message":"Preparing signing request…","progress":2},
    {"stage":"starting","message":"Signing request accepted and queued.","progress":6},
    {"stage":"signing","message":"Signing application bundle.","progress":78}
  ],
  "message": "Local signer is processing the IPA",
  "updatedAt": "2026-10-08T10:00:18.000Z"
}`}</CodeBlock><h3 className="mt-5 font-semibold text-slate-900">Completed response</h3><CodeBlock>{`{
  "success": true,
  "status": "completed",
  "progress": 100,
  "stage": "completed",
  "message": "Signing complete",
  "result": {
    "downloadUrl": "https://xsigner-hncbblmn.manus.space/api/download/sign_abc123",
    "manifestUrl": "https://xsigner-hncbblmn.manus.space/api/manifest?fileId=sign_abc123",
    "otaUrl": "itms-services://?action=download-manifest&url=…",
    "bundleId": "com.example.app",
    "version": "1.0",
    "appName": "My App",
    "fileName": "My-App-1.0.ipa"
  }
}`}</CodeBlock><h3 className="mt-5 font-semibold text-slate-900">Failed response</h3><CodeBlock>{`{
  "success": false,
  "status": "failed",
  "progress": 62,
  "stage": "failed",
  "message": "The provisioning profile does not match the app.",
  "error": "The provisioning profile does not match the app."
}`}</CodeBlock></section>
    <section className={panelClass}><h2 className="text-xl font-semibold">POST /api/v1/discord/custom-sign</h2><p className="mt-2 text-sm leading-6 text-slate-500">Compatibility alias for the same multipart signing logic and response contract as <code>/api/v1/discord/sign</code>. It accepts all fields listed above.</p><CodeBlock>{`curl -X POST https://xsigner-hncbblmn.manus.space/api/v1/discord/custom-sign \
  -H "Authorization: Bearer $XSIGNER_DISCORD_API_KEY" \
  -F ipa=@app.ipa -F certificate=@certificate.p12 \
  -F profile=@profile.mobileprovision -F password=YOUR_P12_PASSWORD \
  -F app_name="My App"`}</CodeBlock></section>
    <section className={panelClass}><h2 className="text-xl font-semibold">GET /api/v1/discord/health</h2><p className="mt-2 text-sm leading-6 text-slate-500">Requires the bearer key and confirms authentication plus signing-engine availability.</p><CodeBlock>{`{
  "status": "ok",
  "service": "xsigner-discord-api",
  "api_version": "1",
  "timestamp": "2026-10-08T10:00:00.000Z",
  "dependencies": {
    "signing_engine": "local-openssl-rcodesign-with-zsign-cross-check",
    "authentication": "configured",
    "auth_mode": "api_key_only"
  },
  "endpoints": {
    "health": "/api/v1/discord/health",
    "sign": "/api/v1/discord/sign",
    "custom_sign": "/api/v1/discord/custom-sign",
    "status": "/api/v1/discord/jobs/{job_id}",
    "progress": "/api/v1/discord/jobs/{job_id}/progress"
  }
}`}</CodeBlock></section>
    <section className={panelClass}><h2 className="text-xl font-semibold">Compatibility and error behavior</h2><ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600"><li><code>OPTIONS /api/v1/discord/custom-sign</code> returns 204 with allowed POST headers.</li><li><code>/api/v1/discord/free-sign</code> returns 404 because Free Sign is not available; use Sign or Custom Sign.</li><li>400 means malformed multipart data or invalid field values; 401 means missing Authorization; 403 means invalid key; 404 means unknown or expired job; 503 means authentication is not configured.</li><li>Passwords and bearer tokens are never returned in responses.</li></ul><CodeBlock>{`{"success":false,"error":"Missing Authorization header. Expected a Bearer token."}
{"success":false,"error":"Job not found, expired, or not available to this API key."}`}</CodeBlock></section>
  </div></div>;
}
function LoadingScreen({ progress }: { progress: number }) {
  return <div role="status" aria-live="polite" aria-label={`Loading Xsign, ${Math.min(progress, 99)} percent`} className="fixed inset-0 z-[100] flex min-h-[100svh] items-center justify-center overflow-hidden bg-[#07111f] px-6 text-slate-100"><div className="xsign-loader-grid absolute inset-0 opacity-30" /><div className="relative w-full max-w-[310px] text-center"><div className="relative mx-auto w-fit rounded-[30px] p-[1px] shadow-[0_0_90px_rgba(49,151,253,.22)]"><div className="rounded-[29px] bg-[#0a1a2d] p-2 ring-1 ring-blue-100/15"><img src="/xsigner-icon.png" alt="XSIGN" className="h-28 w-28 rounded-[22px] object-cover" /></div><span className="xsign-loader-orbit" /></div><h1 className="mt-7 text-2xl font-bold tracking-[.14em] text-white">XSIGN</h1><p className="mt-2 text-[10px] font-semibold uppercase tracking-[.2em] text-sky-200/70">Your signing workspace</p><div className="mt-9"><div className="mb-2.5 flex items-center justify-between text-[10px]"><span className="text-slate-400">Preparing your workspace</span><span className="mono tabular-nums text-sky-200/80">{Math.min(progress, progress === 100 ? 100 : 99)}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-white/[.08]"><div className="h-full rounded-full bg-gradient-to-r from-blue-500 via-sky-300 to-cyan-300 transition-[width] duration-100" style={{ width: `${progress}%` }} /></div></div><div className="mt-5 text-[10px] text-slate-600">Loading site resources <span className="xsign-loader-dots">···</span></div></div></div>; }

export default function StudioApp({ initialPath = "/" }: { initialPath?: string }) {
  const [path, setPath] = useState<PageKey>(() => pageFromPath(initialPath));
  const [mobileOpen, setMobileOpen] = useState(false);
  const [session, setSession] = useState<any>(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [loadProgress, setLoadProgress] = useState(8);
  useEffect(() => {
    let mounted = true;
    const timer = setInterval(() => setLoadProgress((value) => Math.min(value + (value < 65 ? 7 : 2), 94)), 120);
    fetch("/api/auth/session").then((r) => r.json()).then((data) => { if (mounted) setSession(data.user); }).catch(() => { if (mounted) setSession(null); }).finally(() => { clearInterval(timer); if (mounted) { setLoadProgress(100); window.setTimeout(() => mounted && setSessionLoading(false), 260); } });
    return () => { mounted = false; clearInterval(timer); };
  }, []);
  useEffect(() => { const onPop = () => setPath(pageFromPath(window.location.pathname)); window.addEventListener("popstate", onPop); return () => window.removeEventListener("popstate", onPop); }, []);
  const navigate = (next: PageKey) => { const nextPath = pagePaths[next]; window.history.pushState({}, "", nextPath); setPath(next); setMobileOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const visibleGroups = navGroups.map((group) => ({ ...group, items: group.items.filter((item) => (item.href === "auth" ? !session : item.href === "settings" ? Boolean(session) : true)) })).filter((group) => group.items.length);
  const logout = async () => { await fetch("/api/auth/signout", { method: "POST" }); setSession(null); setMobileOpen(false); navigate("auth"); };
  const navigation = <div className="space-y-6">{[...visibleGroups, ...(session?.isOwner ? [{ title: "OWNER", items: [{ href: "owner" as PageKey, label: "Owner console", icon: ShieldAlert }, { href: "discord-api" as PageKey, label: "Discord API", icon: Bot }] }] : [])].map((group) => <div key={group.title}><div className="mono mb-2 px-3 text-[9px] uppercase tracking-[.2em] text-white/25">{group.title}</div><div className="space-y-1">{group.items.map(({ href, label, icon: Icon }) => <button key={href} type="button" onClick={() => navigate(href)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm transition ${path === href ? "bg-[#3197fd]/[.12] text-[#dbeafe]" : "text-white/45 hover:bg-white/[.04] hover:text-white"}`}><Icon size={17} />{label}{path === href && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#3197fd]" />}</button>)}</div></div>)}{session && <button type="button" onClick={logout} className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-slate-600 transition hover:bg-red-50 hover:text-red-700"><LogOut size={17} />Log out</button>}</div>;
  const completeAuth = (user: any) => { setSession(user); navigate("home"); };
  const content = path === "home" ? <HomePage navigate={navigate} /> : path === "auth" ? <AuthPage onAuth={completeAuth} /> : path === "settings" ? (session ? <SettingsPage user={session} /> : <AuthPage onAuth={completeAuth} />) : path === "owner" ? (session?.isOwner ? <OwnerPage /> : <AuthPage onAuth={setSession} />) : path === "discord-api" ? (session?.isOwner ? <DiscordApiPage /> : <AuthPage onAuth={setSession} />) : path === "signer" ? <SignerPage session={session} /> : path === "certificate-checker" ? <CertificateCheckerPage /> : path === "p12-password" ? <P12PasswordPage /> : <FreeCertificatesPage />;
  if (sessionLoading) return <LoadingScreen progress={loadProgress} />;
  return <div className="xsign-workspace min-h-dvh bg-graphite text-white"><aside className="fixed inset-y-0 left-0 z-30 hidden w-[252px] flex-col border-r border-white/[.07] bg-[#091625] p-4 lg:flex"><button type="button" className="rounded-xl p-1 text-left outline-none focus-visible:ring-2 focus-visible:ring-[#3197fd]" onClick={() => navigate("home")}><Brand /></button><div className="my-5 border-t border-white/[.07]" /><div className="min-h-0 flex-1 overflow-y-auto pr-1">{navigation}</div><div className="mt-5 rounded-2xl border border-white/[.07] bg-white/[.025] p-3"><div className="flex items-center gap-2 text-[11px] font-semibold text-white/60"><span className="h-2 w-2 rounded-full bg-[#9ee1d1]" />Local signer online</div><p className="mt-1.5 pl-4 text-[10px] leading-relaxed text-white/30">OpenSSL and rcodesign sign the bundle; zsign independently cross-checks the final IPA.</p></div></aside><header className="sticky top-0 z-20 border-b border-white/[.08] bg-graphite/90 px-4 py-3 backdrop-blur lg:hidden"><div className="flex items-center justify-between"><button type="button" onClick={() => navigate("home")}><Brand compact /></button><button type="button" className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-white/[.04] text-white/70" onClick={() => setMobileOpen((open) => !open)} aria-label={mobileOpen ? "Close navigation" : "Open navigation"}>{mobileOpen ? <X size={19} /> : <Menu size={19} />}</button></div>{mobileOpen && <div className="absolute inset-x-0 top-full border-b border-white/10 bg-[#091625] p-4 shadow-2xl"><div className="max-h-[70vh] overflow-y-auto">{navigation}</div></div>}</header><main className="min-h-dvh lg:pl-[252px]"><div className="console-grid pointer-events-none fixed inset-0 opacity-45" /><div className="relative mx-auto max-w-[1420px] px-4 py-6 sm:px-6 lg:px-10 lg:py-10"><div className="mb-7 hidden items-center justify-between border-b border-white/[.08] pb-5 lg:flex"><div><div className="mono text-[10px] uppercase tracking-[.2em] text-white/25">xsigner / {path}</div><div className="mt-2 text-sm font-semibold text-white/80">{pageTitles[path]}</div></div><div className="flex items-center gap-3"><StatusChip tone="ready">Managed by Manus</StatusChip><span className="mono text-[10px] uppercase tracking-[.15em] text-white/25">v1.0</span></div></div>{content}</div></main></div>;
}
