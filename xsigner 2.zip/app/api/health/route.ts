import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json({ ok: true, service: "xsigner", signer: "local-openssl-rcodesign", retention: "one hour in durable project storage" }, { headers: { "Cache-Control": "no-store" } });
}
