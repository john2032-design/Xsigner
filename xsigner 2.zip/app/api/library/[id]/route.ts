import { NextResponse } from "next/server";
import { deleteLibraryApp, getLibraryApp } from "@/lib/app-library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: Context) {
  const { id } = await context.params;
  const app = getLibraryApp(id);
  if (!app) return NextResponse.json({ error: "That library item is expired or unavailable." }, { status: 404 });
  return new NextResponse(new Uint8Array(app.data), { status: 200, headers: { "Content-Type": "application/octet-stream", "Content-Disposition": `attachment; filename="${app.name.replace(/[^a-zA-Z0-9._-]/g, "_")}"`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}

export async function DELETE(_request: Request, context: Context) {
  const { id } = await context.params;
  if (!deleteLibraryApp(id)) return NextResponse.json({ error: "That library item is expired or unavailable." }, { status: 404 });
  return NextResponse.json({ success: true });
}
