import { NextResponse } from "next/server";
import { listLibraryApps, saveLibraryApp } from "@/lib/app-library";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ apps: listLibraryApps(), retention: "24 hours or until the runtime is recycled" });
}

export async function POST(request: Request) {
  try {
    if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) return NextResponse.json({ error: "Upload the IPA as multipart/form-data." }, { status: 400 });
    const form = await request.formData();
    const ipa = form.get("ipa");
    if (!(ipa instanceof File) || ipa.size === 0 || !ipa.name.toLowerCase().endsWith(".ipa")) return NextResponse.json({ error: "Upload a valid .ipa file." }, { status: 400 });
    if (ipa.size > 250 * 1024 * 1024) return NextResponse.json({ error: "IPA files may not exceed 250 MB." }, { status: 413 });
    const data = Buffer.from(await ipa.arrayBuffer());
    if (!data.subarray(0, 2).equals(Buffer.from("PK"))) return NextResponse.json({ error: "The uploaded file is not a readable IPA archive." }, { status: 400 });
    const app = saveLibraryApp({ name: ipa.name, data });
    return NextResponse.json({ success: true, app: { id: app.id, name: app.name, size: app.size, signed: app.signed, createdAt: app.createdAt } }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "The IPA could not be added to the local App Library." }, { status: 500 });
  }
}
