import { getDiscordJobResponse } from "@/lib/discord-api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function GET(request: Request, context: Context) {
  const { id } = await context.params;
  return getDiscordJobResponse(request, id);
}
