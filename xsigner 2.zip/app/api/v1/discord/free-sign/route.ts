import { NextResponse } from "next/server";

export const runtime = "nodejs";

function removed() {
  return NextResponse.json({ success: false, error: "Free Sign is not available. Use Sign or Custom Sign." }, { status: 404 });
}

export function GET() { return removed(); }
export function POST() { return removed(); }
