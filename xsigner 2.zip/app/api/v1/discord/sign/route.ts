import { startDiscordSigning } from "@/lib/discord-api";
import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  return startDiscordSigning(request);
}

export function GET() {
  return NextResponse.json({ success: false, error: "This endpoint accepts POST multipart/form-data requests only.", endpoint: "/api/v1/discord/sign", method: "POST", fields: ["ipa", "certificate", "profile", "password", "bundleId", "appName", "app_name", "icon", "tweaks"] }, { status: 405, headers: { Allow: "POST, OPTIONS", "Cache-Control": "no-store" } });
}

export function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: { Allow: "POST, OPTIONS", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Authorization, Content-Type" } });
}
