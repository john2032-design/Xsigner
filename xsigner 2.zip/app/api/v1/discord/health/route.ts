import { NextResponse } from "next/server";
import { authorizeDiscord } from "@/lib/discord-api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const auth = authorizeDiscord(request);
  if (auth.error) return auth.error;
  const configured = Boolean(process.env.IOSIGN_DISCORD_API_KEY);
  const status = configured ? "ok" : "degraded";
  return NextResponse.json({ status, service: "xsigner-discord-api", api_version: "1", timestamp: new Date().toISOString(), dependencies: { signing_engine: "local-openssl-rcodesign-with-zsign-cross-check", authentication: configured ? "configured" : "not configured", auth_mode: "api_key_only" }, endpoints: { health: "/api/v1/discord/health", sign: "/api/v1/discord/sign", custom_sign: "/api/v1/discord/custom-sign", status: "/api/v1/discord/jobs/{job_id}", progress: "/api/v1/discord/jobs/{job_id}/progress" } }, { status: configured ? 200 : 503, headers: { "Cache-Control": "no-store" } });
}
