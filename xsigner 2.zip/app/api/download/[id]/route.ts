import { NextResponse } from "next/server";
import { getSignedFile } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const file = await getSignedFile(id);
  if (!file) return NextResponse.json({ error: "This signed package is no longer available." }, { status: 404 });
  const safeName = file.fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  return new NextResponse(new Uint8Array(file.data), { headers: { "Content-Type": "application/octet-stream", "Content-Disposition": `attachment; filename="${safeName}"`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
