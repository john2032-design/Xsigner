import { NextResponse } from "next/server";
import { changeP12Password } from "@/lib/certificates";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) return NextResponse.json({ error: "Send the P12 and passwords as multipart/form-data." }, { status: 400 });
    const form = await request.formData();
    const p12 = form.get("p12");
    const oldPassword = String(form.get("oldPassword") ?? "");
    const newPassword = String(form.get("newPassword") ?? "");
    if (!(p12 instanceof File) || p12.size === 0 || !p12.name.toLowerCase().endsWith(".p12")) return NextResponse.json({ error: "Upload a valid .p12 certificate." }, { status: 400 });
    if (!newPassword) return NextResponse.json({ error: "Enter a new P12 password." }, { status: 400 });
    const output = await changeP12Password(Buffer.from(await p12.arrayBuffer()), oldPassword, newPassword);
    const fileName = `${p12.name.replace(/\.p12$/i, "")}-new-password.p12`;
    return new NextResponse(output, { status: 200, headers: { "Content-Type": "application/x-pkcs12", "Content-Disposition": `attachment; filename="${fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}"`, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "The P12 password could not be changed." }, { status: 422 });
  }
}
