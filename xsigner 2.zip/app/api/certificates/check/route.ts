import { NextResponse } from "next/server";
import { inspectSigningSet } from "@/lib/certificates";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function fileValue(form: FormData, names: string[]) {
  for (const name of names) {
    const value = form.get(name);
    if (value instanceof File && value.size > 0) return value;
  }
  return null;
}

export async function POST(request: Request) {
  try {
    if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) return NextResponse.json({ error: "Send certificate inputs as multipart/form-data." }, { status: 400 });
    const form = await request.formData();
    const mode = String(form.get("mode") ?? "dual");
    const certificate = fileValue(form, ["p12", "certificate"]);
    const profile = fileValue(form, ["profile", "mobileprovision", "provision"]);
    const password = String(form.get("password") ?? "");
    if (!["p12", "profile", "dual"].includes(mode)) return NextResponse.json({ error: "Choose P12, profile, or dual inspection." }, { status: 400 });
    if ((mode === "p12" || mode === "dual") && (!certificate || !certificate.name.toLowerCase().endsWith(".p12"))) return NextResponse.json({ error: "Upload a .p12 certificate for this inspection." }, { status: 400 });
    if ((mode === "profile" || mode === "dual") && (!profile || !profile.name.toLowerCase().endsWith(".mobileprovision"))) return NextResponse.json({ error: "Upload a .mobileprovision profile for this inspection." }, { status: 400 });
        const result = await inspectSigningSet(certificate ? Buffer.from(await certificate.arrayBuffer()) : null, password, profile ? Buffer.from(await profile.arrayBuffer()) : null);
    return NextResponse.json({ success: true, ...result });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "The signing files could not be inspected." }, { status: 422 });
  }
}
