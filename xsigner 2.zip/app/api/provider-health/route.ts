import { NextResponse } from "next/server";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const execFileAsync = promisify(execFile);

async function commandStatus(command: string, args: string[]) {
  try {
    const { stdout } = await execFileAsync(command, args, { timeout: 8_000 });
    return { status: "ready", detail: stdout.trim().split("\n")[0].slice(0, 160) };
  } catch {
    return { status: "unavailable", detail: `${command} is not available in this runtime` };
  }
}

export async function GET() {
  const [openssl, rcodesign, zsign] = await Promise.all([commandStatus("openssl", ["version"]), commandStatus("rcodesign", ["--version"]), commandStatus("zsign", ["-v"])]);
  const discord = process.env.IOSIGN_DISCORD_API_KEY ? "configured" : "not configured";
  const checks = { openssl, rcodesign, zsign, signed_output_storage: { status: "ready", detail: "Signed files are retained for one hour in durable project storage" }, discord_api: { status: discord === "configured" ? "ready" : "setup required", detail: discord === "configured" ? "Bearer authentication is configured" : "Set IOSIGN_DISCORD_API_KEY before using bot routes" } };
  const ready = openssl.status === "ready" && rcodesign.status === "ready" && zsign.status === "ready";
  return NextResponse.json({ status: ready ? "ok" : "degraded", service: "iosign-local-signer", dependencies: checks, timestamp: new Date().toISOString() }, { status: ready ? 200 : 503, headers: { "Cache-Control": "no-store" } });
}
