import { NextResponse } from "next/server";
import { getSignedFile } from "@/lib/store";
import { publicOrigin } from "@/lib/public-origin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function escapeXml(value: string) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const fileId = url.searchParams.get("fileId");
  const file = fileId ? await getSignedFile(fileId) : null;
  if (!file) return NextResponse.json({ error: "This signed package is no longer available." }, { status: 404, headers: { "Access-Control-Allow-Origin": "*" } });
  let signedUrl: URL;
  try {
    signedUrl = new URL(`/api/download/${fileId}`, publicOrigin(request));
  } catch {
    return NextResponse.json({ error: "The public HTTPS site origin is not available for OTA installation." }, { status: 500, headers: { "Access-Control-Allow-Origin": "*" } });
  }
  if (signedUrl.protocol !== "https:") return NextResponse.json({ error: "OTA installation requires a public HTTPS site origin." }, { status: 500, headers: { "Access-Control-Allow-Origin": "*" } });
  const manifest = `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">\n<dict>\n<key>items</key>\n<array>\n<dict>\n<key>assets</key>\n<array>\n<dict>\n<key>kind</key><string>software-package</string>\n<key>url</key><string>${escapeXml(signedUrl.toString())}</string>\n</dict>\n</array>\n<key>metadata</key>\n<dict>\n<key>bundle-identifier</key><string>${escapeXml(file.bundleId)}</string>\n<key>bundle-version</key><string>${escapeXml(file.version)}</string>\n<key>kind</key><string>software</string>\n<key>title</key><string>${escapeXml(file.appName)}</string>\n</dict>\n</dict>\n</array>\n</dict>\n</plist>`;
  return new NextResponse(manifest, { headers: { "Content-Type": "application/xml; charset=utf-8", "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Cache-Control": "no-store" } });
}

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" } });
}
