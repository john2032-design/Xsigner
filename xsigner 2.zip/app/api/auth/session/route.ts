import { NextResponse } from "next/server";
import { sessionUser } from "@/lib/account-auth";
export const runtime = "nodejs";
export async function GET(request: Request) { try { return NextResponse.json({ user: await sessionUser(request) }); } catch { return NextResponse.json({ user: null }); } }
