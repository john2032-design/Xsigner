import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { publicOrigin } from "@/lib/public-origin";
export const runtime = "nodejs";
export async function GET(request: Request) { const state = randomBytes(24).toString("base64url"); const redirect = `${publicOrigin(request)}/api/auth/discord/callback`; const url = new URL("https://discord.com/oauth2/authorize"); url.searchParams.set("client_id", process.env.DISCORD_CLIENT_ID || ""); url.searchParams.set("redirect_uri", redirect); url.searchParams.set("response_type", "code"); url.searchParams.set("scope", "identify"); url.searchParams.set("state", state); return new NextResponse(null, { status: 302, headers: { Location: url.toString(), "Set-Cookie": `xsigner_oauth_state=${state}; Path=/; Max-Age=600; HttpOnly; Secure; SameSite=None` } }); }
