import { NextResponse } from "next/server";
import { clearAuthCookie, destroySession } from "@/lib/account-auth";
export const runtime = "nodejs";
export async function POST(request: Request) { await destroySession(request); return NextResponse.json({ ok: true }, { headers: { "Set-Cookie": clearAuthCookie() } }); }
