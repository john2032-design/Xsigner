import { NextResponse } from "next/server";
import { authCookie, signIn } from "@/lib/account-auth";
export const runtime = "nodejs";
export async function POST(request: Request) { try { const { username, password } = await request.json(); const result = await signIn(String(username ?? ""), String(password ?? ""), request); return NextResponse.json({ user: result.user }, { headers: { "Set-Cookie": authCookie(result.token) } }); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not sign in." }, { status: 401 }); } }
