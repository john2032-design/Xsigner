import { NextResponse } from "next/server";
import { getSigningJob } from "@/lib/signing-jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: Context) {
  const { id } = await context.params;
  const job = await getSigningJob(id);
  if (!job) return NextResponse.json({ error: "Signing job not found." }, { status: 404, headers: { "Cache-Control": "no-store" } });
  return NextResponse.json(job, { headers: { "Cache-Control": "no-store", ...(job.status === "queued" || job.status === "processing" ? { "Retry-After": "1" } : {}) } });
}
