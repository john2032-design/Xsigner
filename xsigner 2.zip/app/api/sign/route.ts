import { NextResponse } from "next/server";
import { SignWorkflowError } from "@/lib/ipa";
import { signIpaInput, type SignInput } from "@/lib/signing-service";
import { publicOrigin } from "@/lib/public-origin";
import { getSavedCertificate, sessionUser } from "@/lib/account-auth";
import { completeSigningJob, createSigningJob, failSigningJob, updateSigningProgress } from "@/lib/signing-jobs";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_IPA_BYTES = 512 * 1024 * 1024;
const MAX_SUPPORT_BYTES = 16 * 1024 * 1024;
const MAX_TWEAK_BYTES = 64 * 1024 * 1024;
const MAX_MULTIPART_BYTES = 640 * 1024 * 1024;
const MAX_TWEAK_FILES = 24;

function asFile(value: FormDataEntryValue | null) {
  return value instanceof File && value.size > 0 ? value : null;
}

function appNameValue(value: FormDataEntryValue | null) {
  const appName = typeof value === "string" ? value.trim() : "";
  if (!appName) return undefined;
  if (appName.length > 80 || /[\u0000-\u001f]/.test(appName)) throw new Error("The app name must be 1–80 printable characters.");
  return appName;
}

async function runJob(jobId: string, input: SignInput, baseUrl: string) {
  try {
    await updateSigningProgress(jobId, { stage: "starting", message: "Signing request accepted and queued.", progress: 6, appName: input.appName, bundleId: input.bundleId });
    const result = await signIpaInput(input, baseUrl, async (event) => {
      await updateSigningProgress(jobId, { ...event, appName: event.stage === "metadata" ? input.appName : undefined, bundleId: input.bundleId });
    });
    await completeSigningJob(jobId, result);
  } catch (error) {
    const message = error instanceof SignWorkflowError ? error.message : error instanceof Error ? error.message : "The signing workflow could not complete.";
    await failSigningJob(jobId, message);
  }
}

export async function POST(request: Request) {
  try {
    if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) return NextResponse.json({ error: "Send signing inputs as multipart/form-data." }, { status: 400 });
    const contentLength = Number(request.headers.get("content-length") ?? 0);
    if (contentLength > MAX_MULTIPART_BYTES) return NextResponse.json({ error: "The request is too large. Keep the IPA under 512 MB and supporting files within their stated limits." }, { status: 413 });
    const form = await request.formData();
    const ipa = asFile(form.get("ipa"));
    let certificate = asFile(form.get("certificate"));
    let profile = asFile(form.get("profile"));
    const icon = asFile(form.get("icon"));
    let password = form.get("password");
    const bundleIdRaw = form.get("bundleId");
    const bundleId = typeof bundleIdRaw === "string" && bundleIdRaw.trim() ? bundleIdRaw.trim() : undefined;
    const appName = appNameValue(form.get("appName"));
    const tweaks = form.getAll("tweaks").filter((entry): entry is File => entry instanceof File && entry.size > 0);
    const user = await sessionUser(request).catch(() => null);

    if (form.get("useSavedCertificate") === "1") {
      if (!user) return NextResponse.json({ error: "Sign in to use your saved signing set." }, { status: 401 });
      const saved = await getSavedCertificate(user.id);
      if (!saved) return NextResponse.json({ error: "Save a P12 and mobileprovision set in Settings first." }, { status: 400 });
      certificate = new File([saved.p12_data], saved.p12_name, { type: "application/x-pkcs12" });
      profile = new File([saved.profile_data], saved.profile_name, { type: "application/octet-stream" });
      password = saved.p12_password;
    }

    if (!ipa || !ipa.name.toLowerCase().endsWith(".ipa")) return NextResponse.json({ error: "Upload a valid .ipa application package." }, { status: 400 });
    if (!certificate || !certificate.name.toLowerCase().endsWith(".p12")) return NextResponse.json({ error: "Upload an Apple certificate with the .p12 extension." }, { status: 400 });
    if (!profile || !profile.name.toLowerCase().endsWith(".mobileprovision")) return NextResponse.json({ error: "Upload a provisioning profile with the .mobileprovision extension." }, { status: 400 });
    if (typeof password !== "string") return NextResponse.json({ error: "The certificate password must be text; leave it blank for a passwordless .p12." }, { status: 400 });
    if (bundleId && !/^[A-Za-z0-9.-]+$/.test(bundleId)) return NextResponse.json({ error: "Use letters, numbers, periods, and hyphens in the custom Bundle ID." }, { status: 400 });
    if (tweaks.length > MAX_TWEAK_FILES) return NextResponse.json({ error: `Upload no more than ${MAX_TWEAK_FILES} tweak files at a time.` }, { status: 413 });
    if (ipa.size > MAX_IPA_BYTES) return NextResponse.json({ error: "The IPA must be 512 MB or smaller." }, { status: 413 });
    if (certificate.size > MAX_SUPPORT_BYTES || profile.size > MAX_SUPPORT_BYTES || (icon && icon.size > MAX_SUPPORT_BYTES)) return NextResponse.json({ error: "The certificate, provisioning profile, and icon must each be 16 MB or smaller." }, { status: 413 });
    if (tweaks.some((entry) => entry.size > MAX_TWEAK_BYTES)) return NextResponse.json({ error: "Each tweak file must be 64 MB or smaller." }, { status: 413 });

    const input: SignInput = {
      ipa: Buffer.from(await ipa.arrayBuffer()),
      certificate: Buffer.from(await certificate.arrayBuffer()),
      profile: Buffer.from(await profile.arrayBuffer()),
      password,
      icon: icon ? Buffer.from(await icon.arrayBuffer()) : undefined,
      bundleId,
      appName,
      tweaks: await Promise.all(tweaks.map(async (entry) => {
        if (!entry.name.toLowerCase().endsWith(".dylib") && !entry.name.toLowerCase().endsWith(".deb")) throw new Error("Tweak files must use the .dylib or .deb extension.");
        return { name: entry.name, data: Buffer.from(await entry.arrayBuffer()) };
      }))
    };
    const job = await createSigningJob({ source: "web", actor: user ? `user:${user.id}` : "web:anonymous", userId: user?.id ?? null, appName, bundleId });
    if (!job) throw new Error("Could not create the signing job.");
    const baseUrl = publicOrigin(request);
    void runJob(job.id, input, baseUrl);
    const statusUrl = `/api/sign/jobs/${encodeURIComponent(job.id)}`;
    return NextResponse.json({ accepted: true, jobId: job.id, statusUrl, pollAfterMs: 1000 }, { status: 202, headers: { "Cache-Control": "no-store", "Retry-After": "1", Location: statusUrl } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "The signing request could not be started." }, { status: 400 });
  }
}
