import { NextResponse } from "next/server";
import { deleteSavedCertificate, getSavedCertificate, saveAvatar, saveCertificate, sessionUser } from "@/lib/account-auth";
import { inspectSigningSet } from "@/lib/certificates";

export const runtime = "nodejs";

function summary(certificate: any, inspection: any) {
  return {
    p12Name: certificate.p12_name,
    profileName: certificate.profile_name,
    p12Organization: inspection?.p12?.subject?.O ?? "",
    p12ExpiresAt: inspection?.p12?.expiresAt ?? "",
    profileExpiresAt: inspection?.mobileprovision?.expiration ?? "",
    p12Status: inspection?.p12?.status ?? "Unknown",
    profileStatus: inspection?.mobileprovision?.status ?? "Unknown",
    signedStatus: inspection?.p12?.status === "Valid" && inspection?.mobileprovision?.status === "Valid" ? "Signed" : "Needs review",
    revocationStatus: "Not checked locally",
    updatedAt: certificate.updated_at
  };
}

async function savedSummary(userId: number) {
  const certificate = await getSavedCertificate(userId);
  if (!certificate) return null;
  const inspection = await inspectSigningSet(Buffer.from(certificate.p12_data), certificate.p12_password, Buffer.from(certificate.profile_data));
  return summary(certificate, inspection);
}

export async function GET(request: Request) {
  try {
    const user = await sessionUser(request);
    if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
    return NextResponse.json({ user, savedCertificate: await savedSummary(user.id) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not load saved certificate." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await sessionUser(request);
    if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
    const form = await request.formData();
    const p12 = form.get("p12");
    const profile = form.get("profile");
    const password = String(form.get("password") ?? "");
    const avatar = form.get("avatar");
    if (avatar instanceof File && avatar.size <= 4 * 1024 * 1024 && /^image\/(png|jpeg|webp)$/.test(avatar.type)) {
      await saveAvatar(user.id, `data:${avatar.type};base64,${Buffer.from(await avatar.arrayBuffer()).toString("base64")}`);
    }
    if (!(p12 instanceof File) && !(profile instanceof File)) return NextResponse.json({ ok: true, profileUpdated: avatar instanceof File, savedCertificate: await savedSummary(user.id) });
    if (!(p12 instanceof File) || !(profile instanceof File)) return NextResponse.json({ error: "Upload both a P12 and mobileprovision file to replace the saved signing set." }, { status: 400 });
    if (!p12.name.toLowerCase().endsWith(".p12") || !profile.name.toLowerCase().endsWith(".mobileprovision")) return NextResponse.json({ error: "Use .p12 and .mobileprovision files." }, { status: 400 });
    if (p12.size > 16 * 1024 * 1024 || profile.size > 16 * 1024 * 1024) return NextResponse.json({ error: "Saved signing files must be 16 MB or smaller." }, { status: 413 });
    const p12Data = Buffer.from(await p12.arrayBuffer());
    const profileData = Buffer.from(await profile.arrayBuffer());
    const inspection = await inspectSigningSet(p12Data, password, profileData);
    await saveCertificate(user.id, p12Data, profileData, p12.name, profile.name, password);
    const saved = await getSavedCertificate(user.id);
    return NextResponse.json({ ok: true, savedCertificate: summary(saved, inspection) });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not save or inspect the signing set." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await sessionUser(request);
    if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
    if (request.headers.get("x-xsigner-confirm") !== "delete-saved-certificate") return NextResponse.json({ error: "Deletion requires explicit confirmation." }, { status: 400 });
    const deleted = await deleteSavedCertificate(user.id);
    return NextResponse.json({ ok: true, deleted });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not delete the saved signing set." }, { status: 400 });
  }
}
