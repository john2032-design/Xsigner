import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ALLOWED_MANIFEST_HOSTS = new Set([
  "xsigner-hncbblmn.manus.space",
  "xsigner.manu.space",
  "localhost",
  "127.0.0.1",
]);

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

export function GET(request: Request) {
  const requestUrl = new URL(request.url);
  const rawOtaUrl = requestUrl.searchParams.get("url");

  if (!rawOtaUrl) {
    return NextResponse.json(
      { error: "Missing OTA URL." },
      { status: 400, headers: { "Cache-Control": "no-store" } },
    );
  }

  let otaUrl: URL;
  let manifestUrl: URL;

  try {
    otaUrl = new URL(rawOtaUrl);
    const manifestValue = otaUrl.searchParams.get("url");
    if (otaUrl.protocol !== "itms-services:" || otaUrl.searchParams.get("action") !== "download-manifest" || !manifestValue) {
      throw new Error("Invalid OTA URL.");
    }

    manifestUrl = new URL(manifestValue);
  } catch {
    return NextResponse.json(
      { error: "Invalid OTA URL." },
      { status: 400, headers: { "Cache-Control": "no-store" } },
    );
  }

  if (manifestUrl.protocol !== "https:" || !ALLOWED_MANIFEST_HOSTS.has(manifestUrl.hostname)) {
    return NextResponse.json(
      { error: "OTA manifest host is not allowed." },
      { status: 403, headers: { "Cache-Control": "no-store" } },
    );
  }

  const escapedOtaUrl = escapeHtml(otaUrl.toString());
  const javascriptOtaUrl = JSON.stringify(otaUrl.toString());
  const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta http-equiv="refresh" content="0;url=${escapedOtaUrl}">
    <title>Install ${escapeHtml(manifestUrl.searchParams.get("id") || "app")}</title>
  </head>
  <body>
    <p>Opening iOS installation…</p>
    <p>If nothing happens, <a href="${escapedOtaUrl}">tap here to continue</a>.</p>
    <script>window.location.replace(${javascriptOtaUrl});</script>
  </body>
</html>`;

  return new Response(html, {
    status: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate",
      "Referrer-Policy": "no-referrer",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
