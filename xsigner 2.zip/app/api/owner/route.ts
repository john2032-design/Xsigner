import { NextResponse } from "next/server";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { deleteExpiredSessions, getOwnerDashboard, isOwnerRequest, recordAudit, sessionUser } from "@/lib/account-auth";
import { deleteExpiredSignedFiles } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const execFileAsync = promisify(execFile);

async function authorized(request: Request) {
  const user = await sessionUser(request);
  return user && isOwnerRequest(request) ? user : null;
}

async function commandStatus(command: string, args: string[]) {
  try {
    const { stdout } = await execFileAsync(command, args, { timeout: 8_000 });
    return { status: "ready", detail: stdout.trim().split("\n")[0].slice(0, 160) };
  } catch {
    return { status: "unavailable", detail: `${command} is unavailable in this runtime` };
  }
}

export async function GET(request: Request) {
  const user = await authorized(request);
  if (!user) return NextResponse.json({ error: "Owner access required." }, { status: 403 });
  const [dashboard, openssl, rcodesign, zsign] = await Promise.all([getOwnerDashboard(), commandStatus("openssl", ["version"]), commandStatus("rcodesign", ["--version"]), commandStatus("zsign", ["-v"])]);
  return NextResponse.json({
    owner: true,
    dashboard,
    discordApi: { sign: "/api/v1/discord/sign", customSign: "/api/v1/discord/custom-sign", health: "/api/v1/discord/health", jobs: "/api/v1/discord/jobs/:id" },
    signer: { openssl, rcodesign, zsign, outputRetention: "1 hour in durable project storage" },
    security: { ownerIp: "168.91.23.165", sessionCookie: "HttpOnly; Secure; SameSite=None", discordApi: process.env.IOSIGN_DISCORD_API_KEY ? "configured" : "not configured" },
    maintenance: { expiredSessionCleanup: true, expiredOutputCleanup: true }
  }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const user = await authorized(request);
  if (!user) return NextResponse.json({ error: "Owner access required." }, { status: 403 });
  const body = await request.json().catch(() => ({}));
  if (body.action === "cleanup-expired-sessions") {
    const deleted = await deleteExpiredSessions();
    await recordAudit("owner.cleaned_sessions", `user:${user.id}`, { deleted });
    return NextResponse.json({ ok: true, deleted });
  }
  if (body.action === "cleanup-expired-outputs") {
    const deleted = await deleteExpiredSignedFiles();
    await recordAudit("owner.cleaned_outputs", `user:${user.id}`, { deleted });
    return NextResponse.json({ ok: true, deleted });
  }
  return NextResponse.json({ error: "Unknown owner action." }, { status: 400 });
}
