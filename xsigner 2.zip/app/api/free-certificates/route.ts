import { NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const API_BASE = "https://sideloading.net";
const allowedStatuses = new Set(["all", "signed", "revoked", "missingP12"]);

export async function GET(request: Request) {
  const url = new URL(request.url);
  const status = url.searchParams.get("status") || "signed";
  const rawAmount = url.searchParams.get("amount") || "";
  const amount = rawAmount ? Number(rawAmount) : null;
  if (!allowedStatuses.has(status)) return NextResponse.json({ error: "Status must be all, signed, revoked, or missingP12." }, { status: 400 });
  if (amount !== null && (!Number.isInteger(amount) || amount < 1 || amount > 100)) return NextResponse.json({ error: "Amount must be an integer between 1 and 100." }, { status: 400 });
  const path = amount === null ? `/api/certificates/list/${status}` : `/api/certificates/list/${status}/${amount}`;
  try {
    const response = await fetch(`${API_BASE}${path}`, { headers: { Accept: "application/json" }, cache: "no-store" });
    const body = await response.text();
    if (!response.ok) return NextResponse.json({ error: "NexCerts returned an error.", detail: body.slice(0, 300) }, { status: response.status });
    const certificates = JSON.parse(body);
    return NextResponse.json({ source: API_BASE, status, amount, certificates }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "The NexCerts certificate list is temporarily unavailable." }, { status: 502 });
  }
}
