import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Xsigner — IPA signing studio",
  description: "A local-first workspace for IPA signing, certificate inspection, and OTA distribution.",
  icons: {
    icon: "/xsigner-icon.png",
    apple: "/xsigner-icon.png"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="dark">
      <body>{children}</body>
    </html>
  );
}
