# iOS signing and tweak-injection research

## Findings applied to Xsigner

1. **zsign is a Linux-compatible IPA signer and validator.** The project documents P12/provisioning-profile signing, IPA output, bundle-name updates, dylib load-command injection, extension injection, and certificate/OCSP checks. Xsigner keeps `rcodesign` as the primary signer and runs `zsign -C` against the final IPA as an independent certificate/OCSP cross-check.
2. **Mach-O injection is only the load-command half of the job.** `insert-dylib` adds `LC_LOAD_DYLIB`/`LC_LOAD_WEAK_DYLIB` entries and strips stale code signatures. Xsigner then stages the libraries inside the app bundle and signs the modified app and nested code again.
3. **A Debian tweak is not automatically a jailed tweak.** Theos documents that `.deb` packages are normally for jailbroken iOS and that each dylib's filter plist controls which bundles/executables receive injection. Xsigner extracts `data.tar.*`, maps each `<library>.plist` to its matching dylib, honors bundle/executable filters, stages frameworks/resources, and reports substrate dependencies.
4. **Jailed/non-jailbroken tweaks need a different runtime assumption.** Theos-jailed describes a separate build model that embeds a compatible substrate implementation into a patched app and re-signs it. A stock IPA signer cannot make a jailbreak-only library that depends on system CydiaSubstrate become self-contained. Xsigner therefore surfaces that dependency in the signing console instead of claiming universal compatibility.

## Large IPA handling

- Browser and Discord routes accept an IPA up to **512 MiB** and return an asynchronous job quickly.
- The multipart request budget remains bounded so the service can accept a 512 MiB IPA plus the supported certificate/profile/icon and one 64 MiB tweak without an unbounded memory request.
- The browser signer now rejects oversized files before upload and shows the selected byte size.
- Signed outputs use durable project storage rather than container-local files.

## References

[1]: https://github.com/zhlynn/zsign "zsign — Fast Cross-Platform iOS Code Signing Tool"
[2]: https://github.com/tyilo/insert_dylib "insert_dylib — Mach-O load-command insertion"
[3]: https://theos.dev/docs/Packaging.html "Theos Packaging — Debian tweak layout and filter property lists"
[4]: https://github.com/BishopFox/theos-jailed "Theos-jailed — jailed-device tweak model"
