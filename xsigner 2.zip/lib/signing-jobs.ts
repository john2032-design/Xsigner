import { randomBytes } from "node:crypto";
import { ensureXsignerSchema, getDatabase, recordAudit } from "@/lib/account-auth";

export type SigningEvent = { timestamp: string; stage: string; message: string; progress: number };
export type SigningJob = {
  id: string;
  source: string;
  actor: string;
  userId: number | null;
  status: "queued" | "processing" | "completed" | "failed";
  progress: number | null;
  stage: string;
  appName: string | null;
  bundleId: string | null;
  events: SigningEvent[];
  result: Record<string, unknown> | null;
  error: string | null;
  createdAt: string;
  updatedAt: string;
};

function parseJson<T>(value: unknown, fallback: T): T {
  if (typeof value !== "string") return fallback;
  try { return JSON.parse(value) as T; } catch { return fallback; }
}

function asJob(row: any): SigningJob {
  return {
    id: row.id,
    source: row.source,
    actor: row.actor,
    userId: row.user_id === null ? null : Number(row.user_id),
    status: row.status,
    progress: row.progress === null ? null : Number(row.progress),
    stage: row.stage,
    appName: row.app_name ?? null,
    bundleId: row.bundle_id ?? null,
    events: parseJson<SigningEvent[]>(row.events, []),
    result: parseJson<Record<string, unknown> | null>(row.result, null),
    error: row.error ?? null,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString()
  };
}

export async function createSigningJob(input: { source: "web" | "discord"; actor: string; userId?: number | null; appName?: string; bundleId?: string }) {
  await ensureXsignerSchema();
  const id = `sign_${randomBytes(16).toString("base64url")}`;
  const event: SigningEvent = { timestamp: new Date().toISOString(), stage: "queued", message: "Preparing signing request…", progress: 2 };
  await getDatabase().query("INSERT INTO xsigner_signing_jobs (id,source,actor,user_id,status,progress,stage,app_name,bundle_id,events) VALUES (?,?,?,?,?,?,?,?,?,?)", [id, input.source, input.actor, input.userId ?? null, "queued", 2, "queued", input.appName ?? null, input.bundleId ?? null, JSON.stringify([event])]);
  await recordAudit("signing.queued", input.actor, { jobId: id, source: input.source, appName: input.appName ?? null });
  return getSigningJob(id);
}

export async function getSigningJob(id: string) {
  await ensureXsignerSchema();
  const [rows] = await getDatabase().query<any[]>("SELECT * FROM xsigner_signing_jobs WHERE id=? LIMIT 1", [id]);
  return rows[0] ? asJob(rows[0]) : null;
}

export async function updateSigningProgress(id: string, update: { stage: string; message: string; progress: number; appName?: string; bundleId?: string }) {
  const job = await getSigningJob(id);
  if (!job) return null;
  const event: SigningEvent = { timestamp: new Date().toISOString(), stage: update.stage, message: update.message.slice(0, 600), progress: Math.max(0, Math.min(100, Math.round(update.progress))) };
  const events = [...job.events, event].slice(-60);
  await getDatabase().query("UPDATE xsigner_signing_jobs SET status='processing',progress=?,stage=?,app_name=COALESCE(?,app_name),bundle_id=COALESCE(?,bundle_id),events=? WHERE id=?", [event.progress, update.stage.slice(0, 96), update.appName ?? null, update.bundleId ?? null, JSON.stringify(events), id]);
  return getSigningJob(id);
}

export async function completeSigningJob(id: string, result: Record<string, unknown>) {
  const job = await getSigningJob(id);
  if (!job) return null;
  const event: SigningEvent = { timestamp: new Date().toISOString(), stage: "completed", message: "Signed package, OTA manifest, and download link are ready.", progress: 100 };
  const events = [...job.events, event].slice(-60);
  await getDatabase().query("UPDATE xsigner_signing_jobs SET status='completed',progress=100,stage='completed',app_name=COALESCE(?,app_name),bundle_id=COALESCE(?,bundle_id),events=?,result=?,error=NULL WHERE id=?", [typeof result.appName === "string" ? result.appName : null, typeof result.bundleId === "string" ? result.bundleId : null, JSON.stringify(events), JSON.stringify(result), id]);
  await recordAudit("signing.completed", job.actor, { jobId: id, appName: result.appName ?? null, source: job.source });
  return getSigningJob(id);
}

export async function failSigningJob(id: string, message: string) {
  const job = await getSigningJob(id);
  if (!job) return null;
  const error = message.slice(0, 600);
  const event: SigningEvent = { timestamp: new Date().toISOString(), stage: "failed", message: error, progress: job.progress ?? 0 };
  const events = [...job.events, event].slice(-60);
  await getDatabase().query("UPDATE xsigner_signing_jobs SET status='failed',stage='failed',events=?,error=? WHERE id=?", [JSON.stringify(events), error, id]);
  await recordAudit("signing.failed", job.actor, { jobId: id, source: job.source });
  return getSigningJob(id);
}
