export function publicOrigin(request: Request) {
  const configured = process.env.PUBLIC_BASE_URL?.trim();
  if (configured) return configured.replace(/\/$/, "");
  const forwardedHost = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim() || request.headers.get("host")?.trim();
  if (forwardedHost && !/^(localhost|127\.0\.0\.1)(:\d+)?$/i.test(forwardedHost)) return `https://${forwardedHost}`;
  const origin = new URL(request.url).origin;
  if (origin.startsWith("https://")) return origin;
  throw new Error("A public HTTPS origin is required to create an OTA installation manifest.");
}
