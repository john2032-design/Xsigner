import mysql from "mysql2/promise";
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

export const OWNER_IP = "168.91.23.165";
const cookieName = "xsigner_session";
let pool: mysql.Pool | null = null;
let schemaReady: Promise<void> | null = null;

export function getDatabase() {
  if (!process.env.DATABASE_URL) throw new Error("Account storage is not configured yet.");
  if (!pool) pool = mysql.createPool({ uri: process.env.DATABASE_URL, connectionLimit: 8, enableKeepAlive: true });
  return pool;
}

export async function ensureXsignerSchema() {
  if (!schemaReady) {
    schemaReady = (async () => {
      const db = getDatabase();
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_users (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(64) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        display_name VARCHAR(128) NULL,
        avatar_data MEDIUMTEXT NULL,
        discord_id VARCHAR(64) NULL UNIQUE,
        discord_username VARCHAR(128) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`);
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_sessions (
        token_hash CHAR(64) PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        expires_at DATETIME NOT NULL,
        INDEX(user_id),
        INDEX(expires_at),
        FOREIGN KEY(user_id) REFERENCES xsigner_users(id) ON DELETE CASCADE
      )`);
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_certificates (
        user_id BIGINT UNSIGNED PRIMARY KEY,
        p12_data MEDIUMBLOB NOT NULL,
        profile_data MEDIUMBLOB NOT NULL,
        p12_name VARCHAR(255) NOT NULL,
        profile_name VARCHAR(255) NOT NULL,
        p12_password TEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES xsigner_users(id) ON DELETE CASCADE
      )`);
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_signed_files (
        id VARCHAR(64) PRIMARY KEY,
        data LONGBLOB NOT NULL,
        storage_key VARCHAR(255) NULL,
        file_name VARCHAR(255) NOT NULL,
        bundle_id VARCHAR(255) NOT NULL,
        app_name VARCHAR(255) NOT NULL,
        version VARCHAR(128) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME NOT NULL,
        INDEX(expires_at)
      )`);
      try {
        await db.query("ALTER TABLE xsigner_signed_files ADD COLUMN storage_key VARCHAR(255) NULL AFTER data");
      } catch (error) {
        if ((error as { code?: string }).code !== "ER_DUP_FIELDNAME") throw error;
      }
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_signing_jobs (
        id VARCHAR(64) PRIMARY KEY,
        source VARCHAR(24) NOT NULL,
        actor VARCHAR(160) NOT NULL,
        user_id BIGINT UNSIGNED NULL,
        status VARCHAR(24) NOT NULL,
        progress TINYINT UNSIGNED NULL,
        stage VARCHAR(96) NOT NULL,
        app_name VARCHAR(255) NULL,
        bundle_id VARCHAR(255) NULL,
        events LONGTEXT NOT NULL,
        result LONGTEXT NULL,
        error TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX(created_at),
        INDEX(status),
        INDEX(user_id)
      )`);
      await db.query(`CREATE TABLE IF NOT EXISTS xsigner_audit_events (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        kind VARCHAR(96) NOT NULL,
        actor VARCHAR(160) NOT NULL,
        detail LONGTEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX(created_at),
        INDEX(kind)
      )`);
    })().catch((error) => {
      schemaReady = null;
      throw error;
    });
  }
  return schemaReady;
}

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `scrypt:${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}

function verifyPassword(password: string, stored: string) {
  const [, salt, digest] = stored.split(":");
  if (!salt || !digest) return false;
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(digest, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function tokenHash(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function clientIp(request: Request) {
  // Only trust headers populated by the hosting edge; never authorize a client-supplied X-Forwarded-For value.
  return request.headers.get("cf-connecting-ip")?.trim() || request.headers.get("x-real-ip")?.trim() || "";
}

export function isOwnerRequest(request: Request) {
  return clientIp(request) === OWNER_IP;
}

export function authCookie(token: string) {
  return `${cookieName}=${token}; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=None`;
}

export function clearAuthCookie() {
  return `${cookieName}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=None`;
}

export async function recordAudit(kind: string, actor: string, detail: Record<string, unknown> = {}) {
  await ensureXsignerSchema();
  await getDatabase().query("INSERT INTO xsigner_audit_events (kind, actor, detail) VALUES (?, ?, ?)", [kind.slice(0, 96), actor.slice(0, 160), JSON.stringify(detail)]);
}

export async function createAccount(username: string, password: string, request: Request) {
  await ensureXsignerSchema();
  if (!/^[A-Za-z0-9_]{3,32}$/.test(username)) throw new Error("Username must be 3–32 letters, numbers, or underscores.");
  if (password.length < 8 || password.length > 128) throw new Error("Password must be 8–128 characters.");
  const [result] = await getDatabase().query<mysql.ResultSetHeader>("INSERT INTO xsigner_users (username, password_hash, display_name) VALUES (?, ?, ?)", [username, hashPassword(password), username]);
  await recordAudit("account.created", `user:${result.insertId}`, { username });
  return startSession(result.insertId, request);
}

export async function signInWithDiscord(discordId: string, discordUsername: string, avatar: string | null, request: Request) {
  await ensureXsignerSchema();
  const db = getDatabase();
  const [rows] = await db.query<any[]>("SELECT id FROM xsigner_users WHERE discord_id=? LIMIT 1", [discordId]);
  let userId = rows[0]?.id;
  if (userId) {
    await db.query("UPDATE xsigner_users SET discord_username=?, avatar_data=? WHERE id=?", [discordUsername, avatar, userId]);
  } else {
    const username = `discord_${discordId.slice(-12)}`;
    const [result] = await db.query<mysql.ResultSetHeader>("INSERT INTO xsigner_users (username,password_hash,display_name,avatar_data,discord_id,discord_username) VALUES (?,?,?,?,?,?)", [username, hashPassword(randomBytes(32).toString("base64url")), discordUsername, avatar, discordId, discordUsername]);
    userId = result.insertId;
  }
  return startSession(userId, request);
}

export async function signIn(username: string, password: string, request: Request) {
  await ensureXsignerSchema();
  const [rows] = await getDatabase().query<any[]>("SELECT * FROM xsigner_users WHERE username=? LIMIT 1", [username]);
  if (!rows[0] || !verifyPassword(password, rows[0].password_hash)) throw new Error("Invalid username or password.");
  await recordAudit("account.signed_in", `user:${rows[0].id}`);
  return startSession(rows[0].id, request);
}

async function startSession(userId: number, request: Request) {
  const token = randomBytes(32).toString("base64url");
  await getDatabase().query("INSERT INTO xsigner_sessions (token_hash,user_id,expires_at) VALUES (?,?,DATE_ADD(NOW(), INTERVAL 30 DAY))", [tokenHash(token), userId]);
  return { token, user: await getUser(userId, request) };
}

export async function getUser(userId: number, request: Request) {
  const [rows] = await getDatabase().query<any[]>("SELECT id,username,display_name,avatar_data,discord_id,discord_username FROM xsigner_users WHERE id=?", [userId]);
  if (!rows[0]) return null;
  return { id: rows[0].id, username: rows[0].username, displayName: rows[0].display_name, avatar: rows[0].avatar_data, discordUsername: rows[0].discord_username, isOwner: isOwnerRequest(request) };
}

export async function sessionUser(request: Request) {
  await ensureXsignerSchema();
  const cookie = request.headers.get("cookie")?.match(new RegExp(`${cookieName}=([^;]+)`))?.[1];
  if (!cookie) return null;
  const [rows] = await getDatabase().query<any[]>("SELECT user_id FROM xsigner_sessions WHERE token_hash=? AND expires_at>NOW()", [tokenHash(cookie)]);
  return rows[0] ? getUser(rows[0].user_id, request) : null;
}

export async function destroySession(request: Request) {
  const cookie = request.headers.get("cookie")?.match(new RegExp(`${cookieName}=([^;]+)`))?.[1];
  if (cookie) await getDatabase().query("DELETE FROM xsigner_sessions WHERE token_hash=?", [tokenHash(cookie)]);
}

export async function saveCertificate(userId: number, p12: Buffer, profile: Buffer, p12Name: string, profileName: string, password: string) {
  await ensureXsignerSchema();
  await getDatabase().query("INSERT INTO xsigner_certificates (user_id,p12_data,profile_data,p12_name,profile_name,p12_password) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE p12_data=VALUES(p12_data),profile_data=VALUES(profile_data),p12_name=VALUES(p12_name),profile_name=VALUES(profile_name),p12_password=VALUES(p12_password)", [userId, p12, profile, p12Name, profileName, password]);
  await recordAudit("certificate.saved", `user:${userId}`, { p12Name, profileName });
}

export async function getSavedCertificate(userId: number) {
  await ensureXsignerSchema();
  const [rows] = await getDatabase().query<any[]>("SELECT * FROM xsigner_certificates WHERE user_id=?", [userId]);
  return rows[0] ?? null;
}

export async function deleteSavedCertificate(userId: number) {
  await ensureXsignerSchema();
  const [result] = await getDatabase().query<mysql.ResultSetHeader>("DELETE FROM xsigner_certificates WHERE user_id=?", [userId]);
  if (result.affectedRows) await recordAudit("certificate.deleted", `user:${userId}`);
  return result.affectedRows > 0;
}

export async function saveAvatar(userId: number, avatar: string | null) {
  await ensureXsignerSchema();
  await getDatabase().query("UPDATE xsigner_users SET avatar_data=? WHERE id=?", [avatar, userId]);
}

export async function deleteExpiredSessions() {
  await ensureXsignerSchema();
  const [result] = await getDatabase().query<mysql.ResultSetHeader>("DELETE FROM xsigner_sessions WHERE expires_at<=NOW()");
  return result.affectedRows ?? 0;
}

function numberValue(value: unknown) {
  return Number(value ?? 0);
}

export async function getOwnerDashboard() {
  await ensureXsignerSchema();
  const db = getDatabase();
  const [[users], [certificates], [sessions], [totalJobs], [completedJobs], [failedJobs], [outputs]] = await Promise.all([
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_users").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_certificates").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_sessions WHERE expires_at>NOW()").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_signing_jobs").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_signing_jobs WHERE status='completed'").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_signing_jobs WHERE status='failed'").then(([rows]) => rows),
    db.query<any[]>("SELECT COUNT(*) AS count FROM xsigner_signed_files WHERE expires_at>NOW()").then(([rows]) => rows)
  ]);
  const [recentJobs] = await db.query<any[]>("SELECT id,source,actor,status,progress,stage,app_name,bundle_id,error,created_at,updated_at FROM xsigner_signing_jobs ORDER BY created_at DESC LIMIT 8");
  const [recentAudit] = await db.query<any[]>("SELECT kind,actor,detail,created_at FROM xsigner_audit_events ORDER BY created_at DESC LIMIT 8");
  return {
    summary: { users: numberValue(users?.count), certificates: numberValue(certificates?.count), activeSessions: numberValue(sessions?.count), jobs: numberValue(totalJobs?.count), completedJobs: numberValue(completedJobs?.count), failedJobs: numberValue(failedJobs?.count), availableOutputs: numberValue(outputs?.count) },
    recentJobs,
    recentAudit
  };
}
