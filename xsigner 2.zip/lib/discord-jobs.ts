import crypto from "node:crypto";

export type DiscordJob = {
  id: string;
  caller: string;
  status: "queued" | "processing" | "completed" | "failed";
  progress: number | null;
  stage: string;
  result?: Record<string, unknown>;
  error?: string;
  createdAt: number;
  updatedAt: number;
};

const jobs = new Map<string, DiscordJob>();
const ttlMs = 1000 * 60 * 60;

function prune() {
  const cutoff = Date.now() - ttlMs;
  for (const [id, job] of jobs) if (job.createdAt < cutoff) jobs.delete(id);
}

export function createDiscordJob(caller: string) {
  prune();
  const now = Date.now();
  const job: DiscordJob = { id: `job_${crypto.randomBytes(14).toString("base64url")}`, caller, status: "queued", progress: 0, stage: "queued", createdAt: now, updatedAt: now };
  jobs.set(job.id, job);
  return job;
}

export function getDiscordJob(id: string, caller: string) {
  prune();
  const job = jobs.get(id);
  return job && job.caller === caller ? job : null;
}

export function updateDiscordJob(job: DiscordJob, patch: Partial<DiscordJob>) {
  Object.assign(job, patch, { updatedAt: Date.now() });
  return job;
}

export function hashCaller(token: string) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
