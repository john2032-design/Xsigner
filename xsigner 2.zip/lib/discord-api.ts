import { createHash, timingSafeEqual } from "node:crypto";
import { NextResponse } from "next/server";
import { SignWorkflowError } from "@/lib/ipa";
import { signIpaInput, type SignInput } from "@/lib/signing-service";
import { completeSigningJob, createSigningJob, failSigningJob, getSigningJob, updateSigningProgress, type SigningJob } from "@/lib/signing-jobs";
import { publicOrigin } from "@/lib/public-origin";

function sameSecret(actual: string, expected: string) {
  const a = Buffer.from(actual);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

// Discord access is deliberately API-key-only. No network address headers are read for authorization.
export function authorizeDiscord(request: Request) {
  const expected = process.env.IOSIGN_DISCORD_API_KEY?.trim();
  if (!expected) return { error: NextResponse.json({ success: false, error: "Discord API authentication is not configured." }, { status: 503 }) };
  const token = (request.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return { error: NextResponse.json({ success: false, error: "Missing Authorization header. Expected a Bearer token." }, { status: 401 }) };
  if (!sameSecret(token, expected)) return { error: NextResponse.json({ success: false, error: "Invalid Discord API authorization token." }, { status: 403 }) };
  return { caller: createHash("sha256").update(token).digest("hex") };
}

async function readFile(form: FormData, names: string[], extension: string) {
  for (const name of names) {
    const value = form.get(name);
    if (value instanceof File && value.size > 0) {
      if (!value.name.toLowerCase().endsWith(extension)) throw new Error(`The ${extension} input must use the ${extension} extension.`);
      return Buffer.from(await value.arrayBuffer());
    }
  }
  return null;
}

function readAppName(form: FormData) {
  const value = String(form.get("appName") ?? form.get("app_name") ?? "").trim();
  if (!value) return undefined;
  if (value.length > 80 || /[\u0000-\u001f]/.test(value)) throw new Error("The appName/app_name field must be 1–80 printable characters.");
  return value;
}

async function readInput(request: Request): Promise<SignInput> {
  if (!(request.headers.get("content-type") ?? "").includes("multipart/form-data")) throw new Error("Send Discord signing inputs as multipart/form-data.");
  const form = await request.formData();
  const ipa = await readFile(form, ["ipa"], ".ipa");
  const certificate = await readFile(form, ["certificate", "cert", "p12"], ".p12");
  const profile = await readFile(form, ["profile", "provision", "mobileprovision"], ".mobileprovision");
  const icon = await readFile(form, ["icon"], ".png");
  const tweaks = form.getAll("tweaks").filter((value): value is File => value instanceof File && value.size > 0);
  const password = String(form.get("password") ?? form.get("p12_password") ?? form.get("p12Password") ?? "");
  const bundleId = String(form.get("bundleId") ?? form.get("bundle_id") ?? "").trim() || undefined;
  const appName = readAppName(form);
  if (!ipa) throw new Error("Missing IPA file.");
  if (!certificate) throw new Error("Missing P12 certificate file.");
  if (!profile) throw new Error("Missing mobileprovision profile file.");
  if (tweaks.length > 24) throw new Error("Upload no more than 24 tweak files at a time.");
  if (bundleId && !/^[A-Za-z0-9.-]+$/.test(bundleId)) throw new Error("Use letters, numbers, periods, and hyphens in the Bundle ID.");
  if (ipa.length > 512 * 1024 * 1024) throw new Error("The IPA must be 512 MB or smaller.");
  if (certificate.length > 16 * 1024 * 1024 || profile.length > 16 * 1024 * 1024 || (icon && icon.length > 16 * 1024 * 1024)) throw new Error("The P12, provisioning profile, and icon must each be 16 MB or smaller.");
  if (tweaks.some((file) => file.size > 64 * 1024 * 1024)) throw new Error("Each tweak file must be 64 MB or smaller.");
  return { ipa, certificate, profile, password, bundleId, appName, icon: icon ?? undefined, tweaks: await Promise.all(tweaks.map(async (file) => {
    if (!file.name.toLowerCase().endsWith(".dylib") && !file.name.toLowerCase().endsWith(".deb")) throw new Error("Tweak files must use the .dylib or .deb extension.");
    return { name: file.name, data: Buffer.from(await file.arrayBuffer()) };
  })) };
}

function serialize(job: SigningJob, request: Request) {
  const origin = publicOrigin(request);
  const statusUrl = `${origin}/api/v1/discord/jobs/${encodeURIComponent(job.id)}`;
  const progressUrl = `${statusUrl}/progress`;
  return {
    success: job.status !== "failed",
    jobId: job.id,
    job_id: job.id,
    status: job.status,
    progress: job.progress,
    stage: job.stage,
    events: job.events,
    message: job.error || (job.status === "completed" ? "Signing complete" : job.status === "processing" ? "Local signer is processing the IPA" : "Request accepted"),
    ...(job.error ? { error: job.error } : {}),
    ...(job.result ? { result: job.result } : {}),
    statusUrl,
    status_url: statusUrl,
    progressUrl,
    progress_url: progressUrl,
    updatedAt: job.updatedAt
  };
}

async function execute(jobId: string, input: SignInput, baseUrl: string) {
  try {
    await updateSigningProgress(jobId, { stage: "starting", message: "Signing request accepted and queued.", progress: 6, appName: input.appName, bundleId: input.bundleId });
    const result = await signIpaInput(input, baseUrl, async (event) => {
      await updateSigningProgress(jobId, { ...event, bundleId: input.bundleId });
    });
    await completeSigningJob(jobId, result);
  } catch (error) {
    const message = error instanceof SignWorkflowError ? error.message : error instanceof Error ? error.message : "The local signer could not complete this job.";
    await failSigningJob(jobId, message);
  }
}

export async function startDiscordSigning(request: Request) {
  const auth = authorizeDiscord(request);
  if (auth.error) return auth.error;
  try {
    const input = await readInput(request);
    const job = await createSigningJob({ source: "discord", actor: `discord:${auth.caller}`, appName: input.appName, bundleId: input.bundleId });
    if (!job) throw new Error("Could not create the signing job.");
    void execute(job.id, input, publicOrigin(request));
    const serialized = serialize(job, request);
    return NextResponse.json({ ...serialized, poll_after_ms: 1000 }, { status: 202, headers: { "Cache-Control": "no-store", "Retry-After": "1", Location: serialized.statusUrl } });
  } catch (error) {
    return NextResponse.json({ success: false, error: error instanceof Error ? error.message : "The Discord signing request could not be read." }, { status: 400 });
  }
}

export async function getDiscordJobResponse(request: Request, id: string) {
  const auth = authorizeDiscord(request);
  if (auth.error) return auth.error;
  const job = await getSigningJob(id);
  if (!job || job.source !== "discord" || job.actor !== `discord:${auth.caller}`) return NextResponse.json({ success: false, error: "Job not found, expired, or not available to this API key." }, { status: 404 });
  return NextResponse.json(serialize(job, request), { status: 200, headers: { "Cache-Control": "no-store", ...(job.status === "queued" || job.status === "processing" ? { "Retry-After": "1" } : {}) } });
}

export function discordCallerFingerprint(request: Request) {
  return createHash("sha256").update(request.headers.get("authorization") ?? "").digest("hex").slice(0, 12);
}
