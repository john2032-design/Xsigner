import AdmZip from "adm-zip";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { parseBuffer } from "bplist-parser";
import * as plist from "plist";

const execFileAsync = promisify(execFile);

type InfoPlist = Record<string, string | number | boolean | unknown>;
export type SigningProgress = { stage: string; message: string; progress: number };
export type ProgressReporter = (event: SigningProgress) => void | Promise<void>;

type ProcessOptions = {
  ipa: Buffer;
  icon?: Buffer;
  bundleId?: string;
  appName?: string;
  tweaks: Array<{ name: string; data: Buffer }>;
  onProgress?: ProgressReporter;
};

type TweakPackage = {
  libraries: string[];
  resources: string[];
  filters: Array<Record<string, unknown>>;
  libraryFilters: Record<string, Array<Record<string, unknown>>>;
  packageName?: string;
  declaresSubstrate: boolean;
};

export class SignWorkflowError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

function commandDetail(error: unknown) {
  if (!error || typeof error !== "object" || !("stderr" in error)) return "";
  return String(error.stderr ?? "").replace(/\s+/g, " ").trim().slice(0, 420);
}

async function report(callback: ProgressReporter | undefined, stage: string, message: string, progress: number) {
  await callback?.({ stage, message, progress });
}

async function verifyWithZsign(ipaPath: string, callback: ProgressReporter | undefined) {
  const executable = process.env.ZSIGN_BIN || "zsign";
  try {
    const { stdout, stderr } = await execFileAsync(executable, ["-C", ipaPath], { timeout: 30_000, maxBuffer: 2 * 1024 * 1024 });
    const detail = (stdout || stderr).replace(/\s+/g, " ").trim();
    await report(callback, "verification", detail ? `zsign cross-check passed. ${detail.slice(0, 220)}` : "zsign cross-check passed for the signed IPA.", 96);
  } catch (error) {
    const code = error && typeof error === "object" && "code" in error ? String(error.code) : "";
    const detail = commandDetail(error);
    await report(callback, "verification", code === "ENOENT" ? "zsign is unavailable in this runtime; rcodesign remains the signing authority." : `zsign cross-check was skipped${detail ? `: ${detail}` : "."}`, 96);
  }
}

async function findAppBundle(payloadDirectory: string) {
  const entries = await fs.readdir(payloadDirectory, { withFileTypes: true });
  const app = entries.find((entry) => entry.isDirectory() && entry.name.endsWith(".app"));
  if (!app) throw new SignWorkflowError("IPA_APP_NOT_FOUND", "The IPA does not contain a Payload/*.app bundle.");
  return path.join(payloadDirectory, app.name);
}

async function walk(directory: string): Promise<string[]> {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(entryPath));
    else if (entry.isFile()) files.push(entryPath);
  }
  return files;
}

function isMachO(buffer: Buffer) {
  if (buffer.length < 4) return false;
  const be = buffer.readUInt32BE(0);
  const le = buffer.readUInt32LE(0);
  return new Set([0xfeedface, 0xfeedfacf, 0xcefaedfe, 0xcffaedfe, 0xcafebabe, 0xcafebabf, 0xbebafeca, 0xbfbafeca]).has(be) ||
    new Set([0xfeedface, 0xfeedfacf, 0xcefaedfe, 0xcffaedfe, 0xcafebabe, 0xcafebabf, 0xbebafeca, 0xbfbafeca]).has(le);
}

function containsAscii(buffer: Buffer, needles: string[]) {
  const text = buffer.toString("latin1");
  return needles.some((needle) => text.includes(needle));
}

function parsePlistBytes(bytes: Buffer): Record<string, unknown> | null {
  try {
    const value = bytes.subarray(0, 8).toString("ascii") === "bplist00" ? parseBuffer(bytes)[0] : plist.parse(bytes.toString("utf8"));
    return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
  } catch {
    return null;
  }
}

async function readPlistFile(filePath: string) {
  try {
    return parsePlistBytes(await fs.readFile(filePath));
  } catch {
    return null;
  }
}

async function walkDirectories(directory: string): Promise<string[]> {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const directories: string[] = [];
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    if (entry.isDirectory()) directories.push(entryPath, ...await walkDirectories(entryPath));
  }
  return directories;
}

async function extractDeb(filePath: string, destination: string): Promise<TweakPackage> {
  const archiveDirectory = path.join(destination, "ar");
  const dataDirectory = path.join(destination, "data");
  await fs.mkdir(archiveDirectory, { recursive: true });
  await fs.mkdir(dataDirectory, { recursive: true });
  try {
    await execFileAsync("ar", ["x", filePath], { cwd: archiveDirectory, maxBuffer: 4 * 1024 * 1024 });
    const archiveEntries = await fs.readdir(archiveDirectory);
    const dataArchive = archiveEntries.find((entry) => /^data\.tar(?:\.|$)/i.test(entry));
    if (!dataArchive) throw new SignWorkflowError("DEB_PAYLOAD_NOT_FOUND", "The .deb tweak has no data.tar payload.");
    await execFileAsync("tar", ["--no-same-owner", "--no-same-permissions", "--extract", "--file", path.join(archiveDirectory, dataArchive), "--directory", dataDirectory], { maxBuffer: 4 * 1024 * 1024 });

    let packageName: string | undefined;
    const controlArchive = archiveEntries.find((entry) => /^control\.tar(?:\.|$)/i.test(entry));
    if (controlArchive) {
      const control = await new Promise<string>((resolve) => {
        execFile("tar", ["-xOf", path.join(archiveDirectory, controlArchive), "./control"], { maxBuffer: 2 * 1024 * 1024 }, (error, stdout) => resolve(error ? "" : stdout));
      });
      packageName = control.match(/^Package:\s*(.+)$/mi)?.[1]?.trim();
    }

    const allFiles = await walk(dataDirectory);
    const libraries = allFiles.filter((file) => file.toLowerCase().endsWith(".dylib"));
    if (!libraries.length) throw new SignWorkflowError("DEB_DYLIB_NOT_FOUND", "The .deb tweak does not contain an injectable .dylib file.");
    const filters: Array<Record<string, unknown>> = [];
    const libraryFilters: Record<string, Array<Record<string, unknown>>> = {};
    for (const file of allFiles.filter((candidate) => candidate.toLowerCase().endsWith(".plist"))) {
      const parsed = await readPlistFile(file);
      if (parsed && ("Filter" in parsed || "Bundles" in parsed || "Executables" in parsed)) {
        filters.push(parsed);
        const libraryName = `${path.basename(file, path.extname(file))}.dylib`.toLowerCase();
        (libraryFilters[libraryName] ??= []).push(parsed);
      }
    }
    const directories = await walkDirectories(dataDirectory);
    const resources = directories.filter((directory) => /\.(bundle|framework)$/i.test(directory));
    const declaresSubstrate = containsAscii(Buffer.concat(await Promise.all(libraries.map((library) => fs.readFile(library)))), ["MobileSubstrate", "CydiaSubstrate", "libsubstrate", "SubstrateLoader"]);
    return { libraries, resources, filters, libraryFilters, packageName, declaresSubstrate };
  } catch (error) {
    if (error instanceof SignWorkflowError) throw error;
    throw new SignWorkflowError("DEB_EXTRACTION_FAILED", "A .deb tweak could not be extracted. Check that the Debian archive is valid and contains iOS dylibs.");
  }
}

function filterMatches(filter: Record<string, unknown>, bundleId: string, executableNames: Set<string>) {
  const filterValue = filter.Filter;
  if (!filterValue || typeof filterValue !== "object" || Array.isArray(filterValue)) return true;
  const record = filterValue as Record<string, unknown>;
  const bundles = Array.isArray(record.Bundles) ? record.Bundles.map(String) : [];
  const executables = Array.isArray(record.Executables) ? record.Executables.map(String) : [];
  if (!bundles.length && !executables.length) return true;
  const bundleMatches = bundles.some((pattern) => pattern === bundleId || new RegExp(`^${pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\\\*/g, ".*")}$`).test(bundleId));
  const executableMatches = executables.some((name) => executableNames.has(name));
  return bundleMatches || executableMatches;
}

async function patchMachO(binaryPath: string, libraries: string[]) {
  const executable = process.env.INSERT_DYLIB_BIN;
  if (!executable) throw new SignWorkflowError("MACHO_PATCHER_NOT_CONFIGURED", "Tweak files were staged, but the Mach-O patcher is not configured.");
  for (const library of libraries) {
    const loadPath = `@executable_path/Frameworks/${path.basename(library)}`;
    try {
      await execFileAsync(executable, ["--ios", "--strip-codesig", "--dylib-path", library, "--inplace", "--all-yes", loadPath, binaryPath], { maxBuffer: 4 * 1024 * 1024 });
    } catch (error) {
      const detail = commandDetail(error);
      throw new SignWorkflowError("MACHO_PATCH_FAILED", detail ? `The executable could not load ${path.basename(library)}. Detail: ${detail}` : `The executable could not load ${path.basename(library)}.`);
    }
  }
}

async function findExecutableBundles(appDirectory: string): Promise<Array<{ directory: string; info: InfoPlist; bundleId: string; executable: string }>> {
  const directories = [appDirectory, ...(await walk(appDirectory)).filter((file) => file.endsWith(".app/Info.plist") || file.endsWith(".appex/Info.plist")).map((file) => path.dirname(file))];
  const result: Array<{ directory: string; info: InfoPlist; bundleId: string; executable: string }> = [];
  for (const directory of [...new Set(directories)]) {
    const info = parsePlistBytes(await fs.readFile(path.join(directory, "Info.plist")).catch(() => Buffer.alloc(0))) as InfoPlist | null;
    if (!info || typeof info.CFBundleIdentifier !== "string" || typeof info.CFBundleExecutable !== "string") continue;
    const executablePath = path.join(directory, info.CFBundleExecutable);
    if ((await fs.stat(executablePath).catch(() => null))?.isFile()) result.push({ directory, info, bundleId: info.CFBundleIdentifier, executable: executablePath });
  }
  return result;
}

async function stageTweakResources(appDirectory: string, sources: string[]) {
  const frameworksDirectory = path.join(appDirectory, "Frameworks");
  await fs.mkdir(frameworksDirectory, { recursive: true });
  for (const source of sources) {
    const name = path.basename(source);
    const destination = path.join(frameworksDirectory, name);
    await fs.cp(source, destination, { recursive: true, force: true });
    if ((await fs.stat(destination).catch(() => null))?.isFile()) await fs.chmod(destination, 0o755);
  }
}

function validatedAppName(value: string | undefined) {
  const appName = value?.trim();
  if (!appName) return undefined;
  if (appName.length > 80 || /[\u0000-\u001f]/.test(appName)) throw new SignWorkflowError("APP_NAME_INVALID", "The app name must be 1–80 printable characters.");
  return appName;
}

export async function preprocessIpa(options: ProcessOptions) {
  const workspace = await fs.mkdtemp(path.join(os.tmpdir(), "xsigner-ipa-"));
  const inputPath = path.join(workspace, "input.ipa");
  const unpackedPath = path.join(workspace, "unpacked");
  const outputPath = path.join(workspace, "modified.ipa");
  await fs.writeFile(inputPath, options.ipa);
  await fs.mkdir(unpackedPath, { recursive: true });
  try {
    await report(options.onProgress, "validating", "Validating the IPA archive and locating the application bundle.", 12);
    new AdmZip(inputPath).extractAllTo(unpackedPath, true);
    const payloadDirectory = path.join(unpackedPath, "Payload");
    const appDirectory = await findAppBundle(payloadDirectory);
    const infoPath = path.join(appDirectory, "Info.plist");
    const info = parsePlistBytes(await fs.readFile(infoPath)) as InfoPlist | null;
    if (!info) throw new SignWorkflowError("PLIST_READ_FAILED", "The app bundle contains an unreadable Info.plist file.");

    await report(options.onProgress, "metadata", "Updating the application metadata and display name.", 24);
    if (options.bundleId) info.CFBundleIdentifier = options.bundleId;
    const appName = validatedAppName(options.appName);
    if (appName) { info.CFBundleDisplayName = appName; info.CFBundleName = appName; }
    if (options.icon) {
      await report(options.onProgress, "icon", "Replacing application icon assets.", 31);
      const appFiles = await walk(appDirectory);
      const iconFiles = appFiles.filter((file) => path.basename(file).startsWith("AppIcon") && file.endsWith(".png"));
      if (!iconFiles.length) throw new SignWorkflowError("APP_ICON_NOT_FOUND", "No AppIcon*.png assets were found in the app bundle.");
      const explicit = ["AppIcon60x60.png", "AppIcon60x60@2x.png", "AppIcon76x76~ipad.png", "AppIcon76x76@2x~ipad.png"];
      await Promise.all([...new Set([...iconFiles, ...explicit.map((file) => path.join(appDirectory, file))])].map((file) => fs.writeFile(file, options.icon as Buffer)));
      await fs.rm(path.join(appDirectory, "Assets.car"), { force: true });
      delete info.CFBundleIconName;
      info.CFBundleIconFiles = ["AppIcon60x60", "AppIcon76x76~ipad"];
    }
    await fs.writeFile(infoPath, plist.build(info as never));

    const tweakDirectory = path.join(workspace, "tweaks");
    await fs.mkdir(tweakDirectory, { recursive: true });
    const packages: TweakPackage[] = [];
    const directLibraries: string[] = [];
    for (const [index, tweak] of options.tweaks.entries()) {
      const safeName = path.basename(tweak.name).replace(/[^A-Za-z0-9._-]/g, "_");
      if (!safeName) throw new SignWorkflowError("TWEAK_NAME_INVALID", "One tweak file has an invalid file name.");
      const tweakPath = path.join(tweakDirectory, `${index}-${safeName}`);
      await fs.writeFile(tweakPath, tweak.data);
      if (safeName.toLowerCase().endsWith(".deb")) packages.push(await extractDeb(tweakPath, path.join(tweakDirectory, `deb-${index}`)));
      else if (safeName.toLowerCase().endsWith(".dylib")) directLibraries.push(tweakPath);
      else throw new SignWorkflowError("TWEAK_TYPE_UNSUPPORTED", `Unsupported tweak type: ${tweak.name}`);
    }

    const libraries = [...directLibraries, ...packages.flatMap((pkg) => pkg.libraries)];
    const resourceSources = packages.flatMap((pkg) => pkg.resources);
    const appBundles = await findExecutableBundles(appDirectory);
    const executableNames = new Set(appBundles.map((bundle) => path.basename(bundle.executable)));
    const appBundleId = typeof info.CFBundleIdentifier === "string" ? info.CFBundleIdentifier : "";
    const applicableFilters = packages.flatMap((pkg) => pkg.filters);
    const filteredLibraries = packages.flatMap((pkg) => pkg.libraries.filter((library) => {
      const filters = pkg.libraryFilters[path.basename(library).toLowerCase()] ?? [];
      return !filters.length || filters.some((filter) => filterMatches(filter, appBundleId, executableNames));
    }));
    const allLibraries = [...directLibraries, ...filteredLibraries];
    const usedNames = new Set<string>();
    const stagedLibraries: string[] = [];
    for (const source of allLibraries) {
      const name = path.basename(source);
      if (usedNames.has(name.toLowerCase())) throw new SignWorkflowError("TWEAK_NAME_COLLISION", `Two selected tweaks contain ${name}. Rename one library before signing.`);
      const bytes = await fs.readFile(source);
      if (!isMachO(bytes)) throw new SignWorkflowError("TWEAK_NOT_MACHO", `${name} is not a Mach-O dynamic library and cannot be injected into an iOS app.`);
      usedNames.add(name.toLowerCase());
      stagedLibraries.push(path.join(appDirectory, "Frameworks", name));
    }

    if (stagedLibraries.length) {
      await report(options.onProgress, "tweaks", `Staging ${stagedLibraries.length} tweak ${stagedLibraries.length === 1 ? "library" : "libraries"}, frameworks, and resources.`, 42);
      await stageTweakResources(appDirectory, allLibraries);
      await stageTweakResources(appDirectory, resourceSources);
      await fs.rm(path.join(appDirectory, "_CodeSignature"), { recursive: true, force: true });
      const targetBundles = appBundles.filter((bundle) => {
        if (bundle.directory === appDirectory) return true;
        return applicableFilters.length === 0 || applicableFilters.some((filter) => filterMatches(filter, bundle.bundleId, new Set([path.basename(bundle.executable)])));
      });
      await report(options.onProgress, "injecting", `Injecting verified tweak libraries into ${targetBundles.length} signed executable bundle${targetBundles.length === 1 ? "" : "s"}.`, 54);
      for (const target of targetBundles) {
        await fs.rm(path.join(target.directory, "_CodeSignature"), { recursive: true, force: true });
        await patchMachO(target.executable, stagedLibraries);
      }
    }

    const substratePackages = packages.filter((pkg) => pkg.declaresSubstrate);
    if (substratePackages.length) {
      await report(options.onProgress, "compatibility", `Detected CydiaSubstrate/jailbreak-runtime dependencies in ${substratePackages.map((pkg) => pkg.packageName || "a Debian tweak").join(", ")}. The IPA was directly injected and signed; install this tweak on a device with its matching jailbreak runtime. Stock iOS cannot provide that runtime through signing alone.`, 60);
    }
    await report(options.onProgress, "packaging", "Packaging the prepared IPA for code signing.", 66);
    const outputArchive = new AdmZip();
    outputArchive.addLocalFolder(payloadDirectory, "Payload");
    outputArchive.writeZip(outputPath);
    return { output: await fs.readFile(outputPath), info };
  } catch (error) {
    if (error instanceof SignWorkflowError) throw error;
    throw new SignWorkflowError("IPA_PROCESSING_FAILED", "The IPA could not be prepared. Confirm the archive is a valid iOS application and that each tweak is a compatible Mach-O library.");
  } finally { await fs.rm(workspace, { recursive: true, force: true }); }
}

export async function signLocally(input: { ipa: Buffer; certificate: Buffer; profile: Buffer; password: string; onProgress?: ProgressReporter }) {
  const workspace = await fs.mkdtemp(path.join(os.tmpdir(), "xsigner-sign-"));
  const inputPath = path.join(workspace, "modified.ipa");
  const certificatePath = path.join(workspace, "certificate.p12");
  const profilePath = path.join(workspace, "profile.mobileprovision");
  const profilePlistPath = path.join(workspace, "profile.plist");
  const entitlementsPath = path.join(workspace, "entitlements.plist");
  const pemPath = path.join(workspace, "signing.pem");
  const passwordPath = path.join(workspace, "certificate-password.txt");
  const unpackedPath = path.join(workspace, "unpacked");
  const outputPath = path.join(workspace, "signed.ipa");
  try {
    await fs.writeFile(inputPath, input.ipa); await fs.writeFile(certificatePath, input.certificate); await fs.writeFile(profilePath, input.profile); await fs.writeFile(passwordPath, input.password); await fs.mkdir(unpackedPath, { recursive: true });
    new AdmZip(inputPath).extractAllTo(unpackedPath, true);
    const appDirectory = await findAppBundle(path.join(unpackedPath, "Payload"));
    await report(input.onProgress, "profile", "Decoding provisioning profile and entitlements.", 72);
    try { await execFileAsync("openssl", ["smime", "-inform", "der", "-verify", "-noverify", "-in", profilePath, "-out", profilePlistPath]); }
    catch (error) { const detail = commandDetail(error); throw new SignWorkflowError("PROFILE_DECODE_FAILED", detail ? `The provisioning profile could not be decoded with OpenSSL. Detail: ${detail}` : "The provisioning profile could not be decoded with OpenSSL. Confirm that the .mobileprovision file is valid."); }
    let profilePlist: Record<string, unknown>;
    try { profilePlist = plist.parse(await fs.readFile(profilePlistPath, "utf8")) as Record<string, unknown>; } catch { throw new SignWorkflowError("PROFILE_PLIST_INVALID", "OpenSSL decoded the provisioning profile, but its plist payload is invalid."); }
    const entitlements = profilePlist.Entitlements;
    if (!entitlements || typeof entitlements !== "object") throw new SignWorkflowError("PROFILE_ENTITLEMENTS_MISSING", "The provisioning profile has no readable entitlements.");
    await fs.writeFile(entitlementsPath, plist.build(entitlements as never)); await fs.copyFile(profilePath, path.join(appDirectory, "embedded.mobileprovision"));
    await report(input.onProgress, "certificate", "Opening the P12 certificate and preparing signing identity.", 81);
    try { await execFileAsync("openssl", ["pkcs12", "-in", certificatePath, "-passin", `file:${passwordPath}`, "-nodes", "-out", pemPath]); }
    catch (error) { const detail = commandDetail(error); throw new SignWorkflowError("P12_READ_FAILED", detail ? `The P12 certificate could not be opened with the supplied password. Detail: ${detail}` : "The P12 certificate could not be opened with the supplied password."); }
    await report(input.onProgress, "signing", "Signing the modified application bundle and nested tweak frameworks with rcodesign; zsign will cross-check the final IPA.", 90);
    try { await execFileAsync("rcodesign", ["sign", "--pem-file", pemPath, "--entitlements-xml-file", entitlementsPath, "--timestamp-url", "none", appDirectory], { maxBuffer: 32 * 1024 * 1024 }); }
    catch (error) { const detail = commandDetail(error); throw new SignWorkflowError("RCODESIGN_FAILED", detail ? `rcodesign rejected the certificate, profile, or modified app bundle. Detail: ${detail}` : "rcodesign rejected the certificate, profile, or modified app bundle."); }
    await report(input.onProgress, "finalizing", "Packaging the signed IPA and preparing OTA metadata.", 97);
    const outputArchive = new AdmZip(); outputArchive.addLocalFolder(path.join(unpackedPath, "Payload"), "Payload"); outputArchive.writeZip(outputPath);
    await verifyWithZsign(outputPath, input.onProgress);
    return await fs.readFile(outputPath);
  } catch (error) { if (error instanceof SignWorkflowError) throw error; throw new SignWorkflowError("LOCAL_SIGNING_FAILED", "The Linux Apple signing toolchain could not sign this app. Check the P12 password, provisioning profile, entitlements, OpenSSL input, tweak dependencies, and rcodesign compatibility."); }
  finally { await fs.rm(workspace, { recursive: true, force: true }); }
}
