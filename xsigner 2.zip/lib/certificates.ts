import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import * as plist from "plist";

const execFileAsync = promisify(execFile);

function detail(error: unknown) {
  if (!error || typeof error !== "object" || !("stderr" in error)) return "";
  return String(error.stderr ?? "").replace(/\s+/g, " ").trim().slice(0, 320);
}

async function runOpenSsl(args: string[]) {
  try {
    return await execFileAsync("openssl", args, { maxBuffer: 12 * 1024 * 1024 });
  } catch (error) {
    const message = detail(error);
    throw new Error(message || "OpenSSL could not process the uploaded signing file.");
  }
}

function parseField(text: string, key: string) {
  const value = text.split("\n").find((line) => line.startsWith(`${key}=`));
  return value ? value.slice(key.length + 1).trim() : "";
}

function parseSubject(value: string) {
  return Object.fromEntries(value.replace(/^subject=/, "").split(/,\s*/).map((part) => {
    const index = part.indexOf("=");
    return index === -1 ? [part.trim(), ""] : [part.slice(0, index).trim(), part.slice(index + 1).trim()];
  }));
}

async function withTempDirectory<T>(prefix: string, action: (directory: string) => Promise<T>) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), prefix));
  try {
    return await action(directory);
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
}

export async function inspectP12(certificate: Buffer, password: string) {
  return withTempDirectory("iosign-p12-check-", async (directory) => {
    const p12Path = path.join(directory, "certificate.p12");
    const passwordPath = path.join(directory, "password.txt");
    const pemPath = path.join(directory, "certificate.pem");
    await fs.writeFile(p12Path, certificate);
    await fs.writeFile(passwordPath, password);
    await runOpenSsl(["pkcs12", "-in", p12Path, "-passin", password ? `file:${passwordPath}` : "pass:", "-clcerts", "-nokeys", "-out", pemPath]);
    const { stdout } = await runOpenSsl(["x509", "-in", pemPath, "-noout", "-subject", "-issuer", "-serial", "-dates", "-fingerprint", "-sha256"]);
    const notBefore = parseField(stdout, "notBefore");
    const notAfter = parseField(stdout, "notAfter");
    return {
      type: "PKCS#12 certificate",
      subject: parseSubject(parseField(stdout, "subject")),
      issuer: parseSubject(parseField(stdout, "issuer")),
      serial: parseField(stdout, "serial"),
      validFrom: notBefore,
      expiresAt: notAfter,
      fingerprint: parseField(stdout, "sha256 Fingerprint"),
      status: new Date(notAfter).getTime() > Date.now() ? "Valid" : "Expired",
    };
  });
}

export async function inspectProvisioningProfile(profile: Buffer) {
  return withTempDirectory("iosign-profile-check-", async (directory) => {
    const profilePath = path.join(directory, "profile.mobileprovision");
    const plistPath = path.join(directory, "profile.plist");
    await fs.writeFile(profilePath, profile);
    await runOpenSsl(["smime", "-inform", "der", "-verify", "-noverify", "-in", profilePath, "-out", plistPath]);
    const data = plist.parse(await fs.readFile(plistPath, "utf8")) as Record<string, unknown>;
    const entitlements = data.Entitlements && typeof data.Entitlements === "object" ? data.Entitlements as Record<string, unknown> : {};
    const expiration = String(data.ExpirationDate ?? "");
    return {
      name: String(data.Name ?? "Unnamed provisioning profile"),
      uuid: String(data.UUID ?? ""),
      teamName: String(data.TeamName ?? ""),
      teamIdentifier: Array.isArray(data.TeamIdentifier) ? String(data.TeamIdentifier[0] ?? "") : String(data.TeamIdentifier ?? ""),
      appId: String(entitlements["application-identifier"] ?? ""),
      applicationIdentifier: String(entitlements["application-identifier"] ?? ""),
      getTaskAllow: Boolean(entitlements["get-task-allow"]),
      expiration,
      status: new Date(expiration).getTime() > Date.now() ? "Valid" : "Expired",
      entitlements,
    };
  });
}

export async function changeP12Password(certificate: Buffer, oldPassword: string, newPassword: string) {
  if (!newPassword || newPassword.length > 256) throw new Error("The new P12 password must contain 1–256 characters.");
  return withTempDirectory("iosign-p12-change-", async (directory) => {
    const p12Path = path.join(directory, "certificate.p12");
    const oldPasswordPath = path.join(directory, "old-password.txt");
    const newPasswordPath = path.join(directory, "new-password.txt");
    const pemPath = path.join(directory, "certificate.pem");
    const outputPath = path.join(directory, "certificate-new.p12");
    await fs.writeFile(p12Path, certificate);
    await fs.writeFile(oldPasswordPath, oldPassword);
    await fs.writeFile(newPasswordPath, newPassword);
    await runOpenSsl(["pkcs12", "-in", p12Path, "-passin", `file:${oldPasswordPath}`, "-nodes", "-out", pemPath]);
    await runOpenSsl(["pkcs12", "-export", "-in", pemPath, "-out", outputPath, "-passout", `file:${newPasswordPath}`]);
    return fs.readFile(outputPath);
  });
}

export async function inspectSigningSet(certificate: Buffer | null, password: string, profile: Buffer | null) {
  const [p12, mobileprovision] = await Promise.all([
    certificate ? inspectP12(certificate, password) : Promise.resolve(null),
    profile ? inspectProvisioningProfile(profile) : Promise.resolve(null),
  ]);
  return { p12, mobileprovision };
}
