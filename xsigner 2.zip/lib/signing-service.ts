import { preprocessIpa, signLocally, type ProgressReporter } from "@/lib/ipa";
import { saveSignedFile } from "@/lib/store";

export type SignInput = {
  ipa: Buffer;
  certificate: Buffer;
  profile: Buffer;
  password: string;
  bundleId?: string;
  appName?: string;
  icon?: Buffer;
  tweaks?: Array<{ name: string; data: Buffer }>;
};

function safeFileComponent(value: string) {
  return value.replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120) || "signed-app";
}

export async function signIpaInput(input: SignInput, baseUrl: string, onProgress?: ProgressReporter) {
  const processed = await preprocessIpa({ ipa: input.ipa, icon: input.icon, bundleId: input.bundleId, appName: input.appName, tweaks: input.tweaks ?? [], onProgress });
  const signed = await signLocally({ ipa: processed.output, certificate: input.certificate, profile: input.profile, password: input.password, onProgress });
  const effectiveBundleId = typeof processed.info.CFBundleIdentifier === "string" ? processed.info.CFBundleIdentifier : "com.xsigner.app";
  const version = typeof processed.info.CFBundleShortVersionString === "string" ? processed.info.CFBundleShortVersionString : "1.0.0";
  const appName = (typeof processed.info.CFBundleDisplayName === "string" && processed.info.CFBundleDisplayName.trim()) || (typeof processed.info.CFBundleName === "string" && processed.info.CFBundleName.trim()) || "Signed App";
  const fileName = `${safeFileComponent(appName)}-${safeFileComponent(version)}.ipa`;
  const fileId = await saveSignedFile({ data: signed, fileName, bundleId: effectiveBundleId, appName, version });
  const origin = baseUrl.replace(/\/$/, "");
  const downloadUrl = new URL(`/api/download/${fileId}`, origin).toString();
  const manifestUrl = new URL(`/api/manifest?fileId=${encodeURIComponent(fileId)}`, origin).toString();
  const otaUrl = `itms-services://?action=download-manifest&url=${encodeURIComponent(manifestUrl)}`;
  await onProgress?.({ stage: "ota", message: `OTA manifest prepared for ${appName}.`, progress: 99 });
  return { downloadUrl, manifestUrl, otaUrl, bundleId: effectiveBundleId, version, appName, fileName };
}
