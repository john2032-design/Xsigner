import crypto from "node:crypto";

type LibraryApp = {
  id: string;
  name: string;
  size: number;
  data: Buffer;
  createdAt: number;
  signed: boolean;
};

const retentionMs = 1000 * 60 * 60 * 24;
const maxApps = 24;
const apps = new Map<string, LibraryApp>();

function prune() {
  const now = Date.now();
  for (const [id, app] of apps) if (now - app.createdAt > retentionMs) apps.delete(id);
  while (apps.size > maxApps) {
    const oldest = apps.keys().next().value;
    if (!oldest) break;
    apps.delete(oldest);
  }
}

export function saveLibraryApp(input: { name: string; data: Buffer }) {
  prune();
  const app: LibraryApp = { id: crypto.randomBytes(12).toString("hex"), name: input.name, size: input.data.length, data: input.data, createdAt: Date.now(), signed: false };
  apps.set(app.id, app);
  return app;
}

export function listLibraryApps() {
  prune();
  return Array.from(apps.values()).sort((a, b) => b.createdAt - a.createdAt).map(({ data, ...app }) => app);
}

export function getLibraryApp(id: string) {
  prune();
  return apps.get(id) ?? null;
}

export function deleteLibraryApp(id: string) {
  return apps.delete(id);
}
