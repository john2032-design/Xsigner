const storageBaseUrl = () => (process.env.MANUS_API_URL ?? "").replace(/\/$/, "");

function storageHeaders() {
  const key = process.env.MANUS_API_KEY?.trim();
  if (!key) throw new Error("Durable object storage is not configured.");
  return { Authorization: `Bearer ${key}` };
}

async function presignedUrl(operation: "put" | "get", objectKey: string) {
  const baseUrl = storageBaseUrl();
  if (!baseUrl) throw new Error("Durable object storage is not configured.");
  const response = await fetch(`${baseUrl}/v1/storage/presign/${operation}?path=${encodeURIComponent(objectKey)}`, {
    headers: storageHeaders(),
    cache: "no-store"
  });
  const payload = await response.json().catch(() => null) as { url?: string; error?: string } | null;
  if (!response.ok || !payload?.url) throw new Error(payload?.error || `Object storage could not prepare a ${operation} URL.`);
  return payload.url;
}

export async function putObject(objectKey: string, data: Buffer) {
  const url = await presignedUrl("put", objectKey);
  const response = await fetch(url, {
    method: "PUT",
    headers: { "Content-Type": "application/octet-stream" },
    body: new Uint8Array(data)
  });
  if (!response.ok) throw new Error(`Object storage rejected the signed IPA upload (${response.status}).`);
}

export async function getObject(objectKey: string) {
  const url = await presignedUrl("get", objectKey);
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) throw new Error(`Object storage could not read the signed IPA (${response.status}).`);
  return Buffer.from(await response.arrayBuffer());
}
