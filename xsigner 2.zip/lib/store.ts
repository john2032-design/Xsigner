import { randomBytes } from "node:crypto";
import { ensureXsignerSchema, getDatabase } from "@/lib/account-auth";
import { getObject, putObject } from "@/lib/object-storage";

const retentionHours = 1;

export type SignedFile = {
  data: Buffer;
  fileName: string;
  bundleId: string;
  appName: string;
  version: string;
  createdAt: Date;
  expiresAt: Date;
};

export async function saveSignedFile(value: { data: Buffer; fileName: string; bundleId: string; appName: string; version: string }) {
  await ensureXsignerSchema();
  const db = getDatabase();
  await db.query("DELETE FROM xsigner_signed_files WHERE expires_at<=NOW()");
  const id = randomBytes(18).toString("hex");
  const storageKey = `xsigner/signed/${id}.ipa`;
  await putObject(storageKey, value.data);
  await db.query("INSERT INTO xsigner_signed_files (id,data,storage_key,file_name,bundle_id,app_name,version,expires_at) VALUES (?,?,?,?,?,?,?,DATE_ADD(NOW(), INTERVAL ? HOUR))", [id, Buffer.alloc(0), storageKey, value.fileName, value.bundleId, value.appName, value.version, retentionHours]);
  return id;
}

export async function getSignedFile(id: string): Promise<SignedFile | null> {
  await ensureXsignerSchema();
  const db = getDatabase();
  await db.query("DELETE FROM xsigner_signed_files WHERE expires_at<=NOW()");
  const [rows] = await db.query<any[]>("SELECT * FROM xsigner_signed_files WHERE id=? AND expires_at>NOW() LIMIT 1", [id]);
  if (!rows[0]) return null;
  const row = rows[0];
  return {
    data: row.storage_key ? await getObject(row.storage_key) : Buffer.from(row.data),
    fileName: row.file_name,
    bundleId: row.bundle_id,
    appName: row.app_name,
    version: row.version,
    createdAt: new Date(row.created_at),
    expiresAt: new Date(row.expires_at)
  };
}

export async function deleteExpiredSignedFiles() {
  await ensureXsignerSchema();
  const [result] = await getDatabase().query<any>("DELETE FROM xsigner_signed_files WHERE expires_at<=NOW()");
  return Number(result.affectedRows ?? 0);
}
