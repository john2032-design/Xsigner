# Xsigner delivery outcomes

- [ ] **Deploy the supplied Xsigner application and icon:** deploy the attached ZIP as Xsigner, use the existing site icon for the favicon, and retain all requested signing functionality.
- [ ] **Apply the shadcn-admin design system:** use the `satnaing/shadcn-admin` template design consistently across every page, tab, component, navigation element, form, dialog, and status view while preserving Xsigner-specific functionality.
- [ ] **Correct app-name and OTA behavior:** enable changing the app name in IPA Signer and Discord API; OTA installation metadata and UI must show the app name rather than a bundle ID; the HTTPS site domain must be the manifest host used for the iOS install prompt.
- [ ] **Repair signing and tweak injection:** sign IPA files with P12/profile inputs; make `.deb` tweaks correctly inject compatible dylibs and re-sign so the installed app can open; show detailed, collapsible live signing progress rather than only “operation in progress.”
- [ ] **Improve saved-certificate behavior:** provide a confirmed delete action for the saved certificate in Settings; when saved-certificate signing is selected, hide certificate and provisioning-profile uploads.
- [ ] **Secure Discord API and owner console:** configure the supplied Discord API key as a server secret, keep it out of client-visible code, and provide an owner-only dashboard with protected site and IPA-signer information restricted to the exact IP `168.91.23.165`.
- [ ] **Validate and publish:** run diagnostics, type checking, production build, route and health checks, create a checkpoint, and publish the deployed Xsigner site.
