# External design reference

Reference: https://github.com/satnaing/shadcn-admin

The referenced project is an admin dashboard UI built with Shadcn and Vite. Search results also describe its conventions as a modern responsive dashboard with sidebar navigation, authentication layouts, data tables, and accessible dashboard patterns. Xsigner will adapt those structural conventions—compact sidebar, clear content hierarchy, responsive cards/forms, and blue/white tokens—without copying source code or assets.
