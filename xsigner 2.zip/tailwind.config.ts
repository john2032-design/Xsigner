import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        graphite: "#07111f",
        ink: "#f5f9ff",
        panel: "#0b1b2b",
        line: "#294663",
        brand: "#3197fd",
        "brand-light": "#54afff",
        blush: "#3197fd",
        mint: "#9ee1d1"
      },
      boxShadow: {
        glow: "0 0 42px rgba(49, 151, 253, 0.15)"
      }
    }
  },
  plugins: []
};

export default config;
