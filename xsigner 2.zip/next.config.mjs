const nextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: "250mb"
    }
  }
};

export default nextConfig;
